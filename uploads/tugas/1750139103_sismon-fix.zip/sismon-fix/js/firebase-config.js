// firebaseConfig.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, initializeFirestore, CACHE_SIZE_UNLIMITED } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getAuth, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyCnYfcVqeNix7hyf1czx5PD6BNTR0xNdmg",
    authDomain: "tujuhebat-75d9d.firebaseapp.com",
    projectId: "tujuhebat-75d9d",
    storageBucket: "tujuhebat-75d9d.firebasestorage.app",
    messagingSenderId: "1042155779289",
    appId: "1:1042155779289:web:9ea609e5cb824d3ddf7ac8",
    measurementId: "G-BCMDF2YLBB"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with cache settings
const db = initializeFirestore(app, {
    cacheSizeBytes: CACHE_SIZE_UNLIMITED,
    experimentalForceLongPolling: true
});

const auth = getAuth(app);

// Cache configuration
const CACHE_CONFIG = {
    DURATION: 5 * 60 * 1000, // 5 minutes
    PREFIX: 'sismon_cache_'
};

// Cache utility functions
const CacheManager = {
    set(key, data) {
        const cacheData = {
            data,
            timestamp: Date.now()
        };
        localStorage.setItem(CACHE_CONFIG.PREFIX + key, JSON.stringify(cacheData));
    },

    get(key) {
        const cached = localStorage.getItem(CACHE_CONFIG.PREFIX + key);
        if (!cached) return null;

        const { data, timestamp } = JSON.parse(cached);
        if (Date.now() - timestamp > CACHE_CONFIG.DURATION) {
            localStorage.removeItem(CACHE_CONFIG.PREFIX + key);
            return null;
        }
        return data;
    },

    clear(key) {
        localStorage.removeItem(CACHE_CONFIG.PREFIX + key);
    },

    clearAll() {
        Object.keys(localStorage)
            .filter(key => key.startsWith(CACHE_CONFIG.PREFIX))
            .forEach(key => localStorage.removeItem(key));
    }
};

// Ekspor semua modul yang dibutuhkan
export { app, db, auth, CacheManager };