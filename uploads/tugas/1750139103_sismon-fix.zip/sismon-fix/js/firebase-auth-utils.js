/**
 * Firebase Authentication Utilities
 * This file contains utility functions for Firebase Authentication management
 */

import { auth, db } from "./firebase-config.js";
import { 
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    sendPasswordResetEmail,
    updateProfile,
    EmailAuthProvider,
    reauthenticateWithCredential,
    updateEmail,
    updatePassword,
    deleteUser
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

import { 
    doc, 
    setDoc, 
    updateDoc, 
    deleteDoc, 
    serverTimestamp,
    getDoc
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

/**
 * Creates a new user with Firebase Authentication and Firestore profile
 * 
 * @param {Object} userData - User data object
 * @param {string} userData.email - User email
 * @param {string} userData.password - User password
 * @param {string} userData.name - User display name
 * @param {string} userData.role - User role (admin, teacher)
 * @param {Object} userData.additionalData - Additional user data
 * @returns {Promise<Object>} - Created user data
 */
export async function createUser(userData) {
    try {
        // Create user with Firebase Authentication
        const userCredential = await createUserWithEmailAndPassword(
            auth,
            userData.email,
            userData.password
        );
        
        const user = userCredential.user;
        
        // Set display name if provided
        if (userData.name) {
            await updateProfile(user, { displayName: userData.name });
        }
        
        // Create user profile in Firestore
        const userProfile = {
            uid: user.uid,
            email: userData.email,
            name: userData.name || '',
            role: userData.role || 'student',
            createdAt: serverTimestamp()
        };
        
        // Only add the specified fields from additionalData
        if (userData.additionalData) {
            // For student role, only include specific fields
            if (userData.role === 'student') {
                const { 
                    nisn, 
                    gender, 
                    class: classId, 
                    parentId, 
                    phone,
                    isEmailVerified,
                    isApproved
                } = userData.additionalData;
                
                // Only add fields if they exist
                if (nisn) userProfile.nisn = nisn;
                if (gender) userProfile.gender = gender;
                if (classId) userProfile.class = classId;
                if (parentId) userProfile.parentId = parentId;
                if (phone) userProfile.phone = phone;
                
                // Always include these boolean fields with defaults if not provided
                userProfile.isEmailVerified = isEmailVerified === true ? true : false;
                userProfile.isApproved = isApproved === true ? true : false;
            } else {
                // For other roles, include all additionalData
                Object.assign(userProfile, userData.additionalData);
            }
        }
        
        // Store user profile in Firestore
        await setDoc(doc(db, "users", user.uid), userProfile);
        
        // If it's a student with a parent, update the parent's children array
        if (userData.role === 'student' && userData.additionalData?.parentId) {
            const parentId = userData.additionalData.parentId;
            const parentRef = doc(db, "users", parentId);
            
            // Get the parent document
            const parentDoc = await getDoc(parentRef);
            
            if (parentDoc.exists()) {
                // Update the parent's children array
                const parentData = parentDoc.data();
                const children = parentData.children || [];
                
                // Only add the child if not already in the array
                if (!children.includes(user.uid)) {
                    await updateDoc(parentRef, {
                        children: [...children, user.uid]
                    });
                }
            }
        }
        
        return {
            uid: user.uid,
            email: user.email,
            name: userData.name,
            role: userProfile.role
        };
    } catch (error) {
        console.error("Error creating user:", error);
        throw error;
    }
}

/**
 * Updates a user's profile in Firestore
 * 
 * @param {string} uid - User ID
 * @param {Object} profileData - Profile data to update
 * @returns {Promise<void>}
 */
export async function updateUserProfile(uid, profileData) {
    try {
        const userRef = doc(db, "users", uid);
        
        // Add timestamp for update
        const dataToUpdate = {
            ...profileData,
            updatedAt: serverTimestamp()
        };
        
        await updateDoc(userRef, dataToUpdate);
        
        return true;
    } catch (error) {
        console.error("Error updating user profile:", error);
        throw error;
    }
}

/**
 * Updates a user's email in both Authentication and Firestore
 * 
 * @param {Object} user - Firebase user object
 * @param {string} newEmail - New email address
 * @param {string} password - Current password for verification
 * @returns {Promise<void>}
 */
export async function updateUserEmail(user, newEmail, password) {
    try {
        // Re-authenticate user before updating email
        const credential = EmailAuthProvider.credential(user.email, password);
        await reauthenticateWithCredential(user, credential);
        
        // Update email in Authentication
        await updateEmail(user, newEmail);
        
        // Update email in Firestore
        await updateUserProfile(user.uid, { email: newEmail });
        
        return true;
    } catch (error) {
        console.error("Error updating user email:", error);
        throw error;
    }
}

/**
 * Updates a user's password
 * 
 * @param {Object} user - Firebase user object
 * @param {string} currentPassword - Current password for verification
 * @param {string} newPassword - New password
 * @returns {Promise<void>}
 */
export async function changePassword(user, currentPassword, newPassword) {
    try {
        // Re-authenticate user before changing password
        const credential = EmailAuthProvider.credential(user.email, currentPassword);
        await reauthenticateWithCredential(user, credential);
        
        // Update password
        await updatePassword(user, newPassword);
        
        return true;
    } catch (error) {
        console.error("Error changing password:", error);
        throw error;
    }
}

/**
 * Sends a password reset email to the specified email address
 * 
 * @param {string} email - User email address
 * @returns {Promise<void>}
 */
export async function sendPasswordReset(email) {
    try {
        await sendPasswordResetEmail(auth, email);
        return true;
    } catch (error) {
        console.error("Error sending password reset:", error);
        throw error;
    }
}

/**
 * Deletes a user from both Authentication and Firestore
 * 
 * @param {Object} user - Firebase user object
 * @param {string} password - Current password for verification
 * @returns {Promise<void>}
 */
export async function deleteUserAccount(user, password) {
    try {
        // Re-authenticate user before deletion
        const credential = EmailAuthProvider.credential(user.email, password);
        await reauthenticateWithCredential(user, credential);
        
        // Delete Firestore profile first
        await deleteDoc(doc(db, "users", user.uid));
        
        // Delete Authentication user
        await deleteUser(user);
        
        return true;
    } catch (error) {
        console.error("Error deleting user:", error);
        throw error;
    }
} 