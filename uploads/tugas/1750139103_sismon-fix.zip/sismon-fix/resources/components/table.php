<?php
$pageTitle = "Tables"; // Set judul halaman
require_once('components/header.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Konten halaman tables -->
</div>

<?php require_once('components/footer.php'); ?>