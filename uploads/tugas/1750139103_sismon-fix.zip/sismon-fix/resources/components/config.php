<?php
// Default page title
$pageTitle = isset($pageTitle) ? $pageTitle : "SB Admin 2";
?>