import { collection, getDocs, doc, getDoc, query, where } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { db } from "./firebase-config.js";
import { openEditModal, openChangeClassModal, openDeleteModal } from "./student-management.js";

let dataTable;
let selectionMode = false;

// Initialize DataTable with checkbox column
function initializeDataTable() {
    dataTable = $('#dataTable').DataTable({
        paging: true,
        lengthChange: true,
        searching: true,
        ordering: true,
        info: true,
        autoWidth: false,
        responsive: true,
        destroy: true,
        language: {
            emptyTable: "Tidak ada data",
            zeroRecords: "Tidak ada data yang cocok dengan pencarian"
        },
        columnDefs: [
            {
                targets: 0,
                searchable: false,
                orderable: false,
                className: 'dt-body-center',
                render: function (data, type, full, meta) {
                    return '<input type="checkbox" class="student-checkbox" value="' + data + '">';
                },
                visible: false // Checkbox column initially hidden
            },
            {
                targets: 1,
                searchable: false,
                orderable: false
            },
            {
                targets: -1, // Last column (Actions)
                searchable: false,
                orderable: false,
                className: 'dt-body-center',
                render: function (data, type, full, meta) {
                    return `
                        <div class="dropdown">
                            <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="actionDropdown${full[0]}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Aksi
                            </button>
                            <div class="dropdown-menu" aria-labelledby="actionDropdown${full[0]}">
                                <a class="dropdown-item edit-btn" href="#" data-uid="${full[0]}">Edit</a>
                                <a class="dropdown-item detail-btn" href="#" data-uid="${full[0]}">Detail</a>
                                <a class="dropdown-item change-class-btn" href="#" data-uid="${full[0]}">Ubah Kelas</a>
                                <a class="dropdown-item delete-btn" href="#" data-uid="${full[0]}">Hapus</a>
                            </div>
                        </div>
                    `;
                }
            }
        ],
        drawCallback: function(settings) {
            let api = this.api();
            let start = api.page.info().start;
            api.column(1, { search: 'applied', order: 'applied' }).nodes().each(function(cell, i) {
                cell.innerHTML = start + i + 1;
            });
            
            // Add event listeners for action buttons
            $('.edit-btn').on('click', function() {
                const uid = $(this).data('uid');
                openEditModal(uid);
            });
            
            $('.detail-btn').on('click', function() {
                const uid = $(this).data('uid');
                window.location.href = `detail.html?uid=${uid}`;
            });
            
            $('.change-class-btn').on('click', function() {
                const uid = $(this).data('uid');
                openChangeClassModal([uid]);
            });
            
            $('.delete-btn').on('click', function() {
                const uid = $(this).data('uid');
                openDeleteModal(uid);
            });
        }
    });

    // Event listener for "Select All" checkbox
    $('#selectAll').on('click', function() {
        $('.student-checkbox').prop('checked', this.checked);
    });

    // Event listener to update "Select All" status
    $('#dataTable tbody').on('change', '.student-checkbox', function() {
        const allChecked = $('.student-checkbox:checked').length === $('.student-checkbox').length;
        $('#selectAll').prop('checked', allChecked);
    });
}

// Load class options into the dropdown filters
async function loadClassOptions() {
    try {
        const classFilter = document.getElementById('classFilter');
        const classesSnapshot = await getDocs(collection(db, "classes"));
        
        // Add class options from database to filter dropdown
        classesSnapshot.forEach((classDoc) => {
            const classData = classDoc.data();
            const option = document.createElement('option');
            option.value = classDoc.id;
            option.textContent = classData.className;
            classFilter.appendChild(option);
        });
        
        // Also add to class change modal dropdown
        const classDropdown = document.getElementById('targetClass');
        if (classDropdown) {
            classesSnapshot.forEach((classDoc) => {
                const classData = classDoc.data();
                const option = document.createElement('option');
                option.value = classDoc.id;
                option.textContent = classData.className;
                classDropdown.appendChild(option);
            });
        }
    } catch (error) {
        console.error("Error loading class options:", error);
        alert("Gagal memuat opsi kelas");
    }
}

// Load student data based on class filter
async function loadStudentData(classId = '') {
    try {
        if (!dataTable) {
            console.error("DataTable belum diinisialisasi");
            return;
        }

        dataTable.clear();
        const usersCollection = collection(db, "users");
        let usersSnapshot;

        // Filter by class if classId is provided
        if (classId) {
            const q = query(usersCollection, where("role", "==", "student"), where("class", "==", classId));
            usersSnapshot = await getDocs(q);
        } else {
            const q = query(usersCollection, where("role", "==", "student"));
            usersSnapshot = await getDocs(q);
        }

        // Check if data exists
        if (usersSnapshot.empty) {
            dataTable.draw();
            return;
        }

        for (const userDoc of usersSnapshot.docs) {
            const userData = userDoc.data();
            
            // Get class data
            const classDocRef = doc(db, "classes", userData.class);
            const classDocSnap = await getDoc(classDocRef);
            const className = classDocSnap.exists() ? classDocSnap.data().className : "Kelas tidak ditemukan";
            
            // Get activity data
            const activitiesSnapshot = await getDocs(collection(db, "users", userDoc.id, "activities"));
            const approvedActivitiesCount = activitiesSnapshot.docs.filter(activityDoc => activityDoc.data().validated === true).length;
            
            // Add row to DataTable
            dataTable.row.add([
                userData.uid, // Using uid field as checkbox value
                "", // Placeholder for number
                userData.name || "Nama tidak tersedia",
                userData.email || "Email tidak tersedia",
                className,
                userData.phone || "No. HP tidak tersedia",
                activitiesSnapshot.size,
                approvedActivitiesCount,
                "" // Placeholder for actions column
            ]);
        }
        
        dataTable.draw();
        
        // Adjust column visibility based on selection mode
        dataTable.column(0).visible(selectionMode);
        
        // If in selection mode and "Select All" clicked, check all checkboxes
        if (selectionMode && $('#selectAll').prop('checked')) {
            $('.student-checkbox').prop('checked', true);
        }
    } catch (error) {
        console.error("Error loading student data:", error);
        dataTable.clear().draw();
        const tableBody = document.querySelector("#dataTable tbody");
        tableBody.innerHTML = `<tr><td colspan="9" class="text-danger">Gagal mengambil data: ${error.message}</td></tr>`;
    }
}

// Get IDs of selected students
function getSelectedStudentIds() {
    const selectedIds = [];
    $('.student-checkbox:checked').each(function() {
        selectedIds.push($(this).val());
    });
    return selectedIds;
}

export { initializeDataTable, loadClassOptions, loadStudentData, getSelectedStudentIds, dataTable, selectionMode };