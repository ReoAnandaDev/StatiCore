import { dataTable, getSelectedStudentIds, loadStudentData } from "./table.js";
import { openChangeClassModal } from "./student-management.js";
import { currentUser } from "./auth.js";
import { EmailAuthProvider, reauthenticateWithCredential } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { collection, getDocs, doc, query, where, writeBatch, deleteDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { db } from "./firebase-config.js";

let selectionMode = false;

// Add selection mode buttons to UI
function addSelectionButtons() {
    const filterRow = document.querySelector(".row.mb-3");
    
    // Create div for button group
    const buttonCol = document.createElement('div');
    buttonCol.className = 'col-md-6 d-flex align-items-end';
    
    // Create div for buttons
    const buttonGroup = document.createElement('div');
    buttonGroup.className = 'btn-group';
    
    // Create "Select User" button
    const selectUserBtn = document.createElement('button');
    selectUserBtn.id = 'selectUserBtn';
    selectUserBtn.className = 'btn btn-primary';
    selectUserBtn.textContent = 'Pilih User';
    selectUserBtn.addEventListener('click', toggleSelectionMode);
    
    // Create "Select All" button
    const selectAllBtn = document.createElement('button');
    selectAllBtn.id = 'selectAllUsersBtn';
    selectAllBtn.className = 'btn btn-info';
    selectAllBtn.textContent = 'Pilih Semua';
    selectAllBtn.style.display = 'none'; // Initially hidden
    selectAllBtn.addEventListener('click', selectAllUsers);
    
    // Create dropdown button for bulk actions
    const dropdownBtn = document.createElement('button');
    dropdownBtn.id = 'bulkActionBtn';
    dropdownBtn.className = 'btn btn-secondary dropdown-toggle';
    dropdownBtn.textContent = 'Aksi';
    dropdownBtn.setAttribute('data-toggle', 'dropdown');
    dropdownBtn.setAttribute('aria-haspopup', 'true');
    dropdownBtn.setAttribute('aria-expanded', 'false');
    dropdownBtn.style.display = 'none'; // Initially hidden
    
    // Create dropdown menu
    const dropdownMenu = document.createElement('div');
    dropdownMenu.className = 'dropdown-menu';
    
    // Add dropdown item for class change
    const changeClassItem = document.createElement('a');
    changeClassItem.className = 'dropdown-item';
    changeClassItem.href = '#';
    changeClassItem.textContent = 'Ubah Kelas';
    changeClassItem.addEventListener('click', bulkChangeClass);
    
    // Add dropdown item for data deletion
    const deleteItem = document.createElement('a');
    deleteItem.className = 'dropdown-item';
    deleteItem.href = '#';
    deleteItem.textContent = 'Hapus Data';
    deleteItem.addEventListener('click', openBulkDeleteModal);
    
    // Add items to dropdown menu
    dropdownMenu.appendChild(changeClassItem);
    dropdownMenu.appendChild(deleteItem);
    
    // Add buttons to button group
    buttonGroup.appendChild(selectUserBtn);
    buttonGroup.appendChild(selectAllBtn);
    buttonGroup.appendChild(dropdownBtn);
    buttonGroup.appendChild(dropdownMenu);
    
    // Add button group to column
    buttonCol.appendChild(buttonGroup);
    
    // Add column to row
    filterRow.appendChild(buttonCol);
}

// Toggle selection mode
function toggleSelectionMode() {
    selectionMode = !selectionMode;
    const selectUserBtn = document.getElementById('selectUserBtn');
    const selectAllUsersBtn = document.getElementById('selectAllUsersBtn');
    const bulkActionBtn = document.getElementById('bulkActionBtn');
    
    if (selectionMode) {
        selectUserBtn.textContent = 'Batal Pilih';
        selectUserBtn.className = 'btn btn-danger';
        selectAllUsersBtn.style.display = 'inline-block';
        bulkActionBtn.style.display = 'inline-block';
        
        // Show checkbox column
        dataTable.column(0).visible(true);
    } else {
        selectUserBtn.textContent = 'Pilih User';
        selectUserBtn.className = 'btn btn-primary';
        selectAllUsersBtn.style.display = 'none';
        bulkActionBtn.style.display = 'none';
        
        // Hide checkbox column
        dataTable.column(0).visible(false);
        
        // Reset all checkboxes
        $('#selectAll').prop('checked', false);
        $('.student-checkbox').prop('checked', false);
    }
    
    // Reload data to apply changes
    loadStudentData(document.getElementById('classFilter').value);
}

// Select all users
function selectAllUsers() {
    // Select all users and mark checkboxes visually
    $('#selectAll').prop('checked', true);
    $('.student-checkbox').prop('checked', true);
    
    console.log("Semua user telah dipilih");
}

// Start class change process (for selection mode)
function bulkChangeClass() {
    const selectedIds = getSelectedStudentIds();
    if (selectedIds.length === 0) {
        alert("Pilih siswa terlebih dahulu");
        return;
    }
    
    openChangeClassModal(selectedIds);
}

// Open bulk delete modal
function openBulkDeleteModal() {
    const selectedIds = getSelectedStudentIds();
    if (selectedIds.length === 0) {
        alert("Pilih siswa terlebih dahulu");
        return;
    }
    
    // Reset form
    document.getElementById('bulkDeleteForm').reset();
    
    // Set user IDs to delete
    document.getElementById('bulkDeleteUserIds').value = JSON.stringify(selectedIds);
    
    // Open modal
    $('#bulkDeleteModal').modal('show');
}

// Delete multiple users at once
async function bulkDelete() {
    try {
        const userIds = JSON.parse(document.getElementById('bulkDeleteUserIds').value);
        const adminPassword = document.getElementById('bulkDeleteAdminPassword').value;
        
        if (!adminPassword) {
            alert("Masukkan password admin untuk melanjutkan");
            return;
        }
        
        // Verify admin password
        try {
            const credential = EmailAuthProvider.credential(currentUser.email, adminPassword);
            await reauthenticateWithCredential(currentUser, credential);
        } catch (error) {
            console.error("Authentication failed:", error);
            alert("Password salah. Silakan coba lagi.");
            return;
        }
        
        const batch = writeBatch(db);
        
        for (const uid of userIds) {
            // Find user document by uid
            const q = query(collection(db, "users"), where("uid", "==", uid));
            const querySnapshot = await getDocs(q);
            
            if (!querySnapshot.empty) {
                const userDoc = querySnapshot.docs[0];
                
                // Delete user document
                batch.delete(doc(db, "users", userDoc.id));
            }
        }
        
        await batch.commit();
        
        // Close modal and refresh data
        $('#bulkDeleteModal').modal('hide');
        loadStudentData(document.getElementById('classFilter').value);
        
        alert(`${userIds.length} user berhasil dihapus`);
    } catch (error) {
        console.error("Error bulk deleting users:", error);
        alert(`Gagal menghapus user: ${error.message}`);
    }
}

export { 
    addSelectionButtons, 
    toggleSelectionMode, 
    selectAllUsers, 
    bulkChangeClass, 
    openBulkDeleteModal, 
    bulkDelete,
    selectionMode
};