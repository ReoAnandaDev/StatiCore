import { collection, getDocs, doc, getDoc, query, where, updateDoc, deleteDoc, writeBatch } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { updateEmail, updatePassword, EmailAuthProvider, reauthenticateWithCredential } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { db, auth } from "./firebase-config.js";
import { loadStudentData } from "./table.js";
import { currentUser } from "./auth.js";

// Open edit user modal
async function openEditModal(uid) {
    try {
        // Reset form
        document.getElementById('editUserForm').reset();
        
        // Set user ID to edit
        document.getElementById('editUserId').value = uid;
        
        // Find user data by uid
        const q = query(collection(db, "users"), where("uid", "==", uid));
        const querySnapshot = await getDocs(q);
        
        if (!querySnapshot.empty) {
            const userData = querySnapshot.docs[0].data();
            
            // Fill form with user data
            document.getElementById('editName').value = userData.name || '';
            document.getElementById('editPhone').value = userData.phone || '';
            document.getElementById('editEmail').value = userData.email || '';
            
            // Open modal
            $('#editUserModal').modal('show');
        } else {
            alert("Data user tidak ditemukan");
        }
    } catch (error) {
        console.error("Error opening edit modal:", error);
        alert(`Gagal membuka modal edit: ${error.message}`);
    }
}

// Save user edits
async function saveUserEdit() {
    try {
        const userId = document.getElementById('editUserId').value;
        const name = document.getElementById('editName').value;
        const phone = document.getElementById('editPhone').value;
        const email = document.getElementById('editEmail').value;
        const password = document.getElementById('editPassword').value;
        
        // Validate input
        if (!name || !email) {
            alert("Nama dan email harus diisi");
            return;
        }
        
        // Find user document by uid
        const q = query(collection(db, "users"), where("uid", "==", userId));
        const querySnapshot = await getDocs(q);
        
        if (!querySnapshot.empty) {
            const userDoc = querySnapshot.docs[0];
            const userData = userDoc.data();
            const oldEmail = userData.email;
            
            // Update data in Firestore
            await updateDoc(doc(db, "users", userDoc.id), {
                name: name,
                phone: phone,
                email: email
            });
            
            // Update email and password in Firebase Auth if needed
            if (email !== oldEmail || password) {
                // Reauthenticate user first (required for sensitive operations)
                const credential = EmailAuthProvider.credential(currentUser.email, document.getElementById('adminPassword').value);
                await reauthenticateWithCredential(currentUser, credential);
                
                // Update email if changed
                if (email !== oldEmail) {
                    await updateEmail(auth.currentUser, email);
                }
                
                // Update password if filled
                if (password) {
                    await updatePassword(auth.currentUser, password);
                }
            }
            
            // Close modal and refresh data
            $('#editUserModal').modal('hide');
            loadStudentData(document.getElementById('classFilter').value);
            
            alert("Data user berhasil diperbarui");
        } else {
            alert("Data user tidak ditemukan");
        }
    } catch (error) {
        console.error("Error saving user edit:", error);
        alert(`Gagal menyimpan perubahan: ${error.message}`);
    }
}

// Open change class modal
function openChangeClassModal(userIds) {
    // Set user IDs to change class
    document.getElementById('selectedUserIds').value = JSON.stringify(userIds);
    
    // Open modal
    $('#changeClassModal').modal('show');
}

// Save class change
async function saveClassChange() {
    try {
        const userIds = JSON.parse(document.getElementById('selectedUserIds').value);
        const targetClassId = document.getElementById('targetClass').value;
        
        if (!userIds.length || !targetClassId) {
            alert("Pilih siswa dan kelas tujuan terlebih dahulu");
            return;
        }
        
        const batch = writeBatch(db);
        
        for (const uid of userIds) {
            // Find user document by uid
            const q = query(collection(db, "users"), where("uid", "==", uid));
            const querySnapshot = await getDocs(q);
            
            if (!querySnapshot.empty) {
                const userDoc = querySnapshot.docs[0];
                batch.update(doc(db, "users", userDoc.id), {
                    class: targetClassId
                });
            }
        }
        
        await batch.commit();
        
        // Close modal and refresh data
        $('#changeClassModal').modal('hide');
        loadStudentData(document.getElementById('classFilter').value);
        
        alert("Berhasil memindahkan siswa ke kelas baru");
    } catch (error) {
        console.error("Error changing class:", error);
        alert(`Gagal mengubah kelas: ${error.message}`);
    }
}

// Open delete modal
function openDeleteModal(uid) {
    // Reset form
    document.getElementById('deleteUserForm').reset();
    
    // Set user ID to delete
    document.getElementById('deleteUserId').value = uid;
    
    // Open modal
    $('#deleteUserModal').modal('show');
}

// Confirm user deletion
async function confirmDelete() {
    try {
        const userId = document.getElementById('deleteUserId').value;
        const adminPassword = document.getElementById('adminPassword').value;
        
        if (!adminPassword) {
            alert("Masukkan password admin untuk melanjutkan");
            return;
        }
        
        // Verify admin password
        try {
            const credential = EmailAuthProvider.credential(currentUser.email, adminPassword);
            await reauthenticateWithCredential(currentUser, credential);
        } catch (error) {
            console.error("Authentication failed:", error);
            alert("Password salah. Silakan coba lagi.");
            return;
        }
        
        // Find user document by uid
        const q = query(collection(db, "users"), where("uid", "==", userId));
        const querySnapshot = await getDocs(q);
        
        if (!querySnapshot.empty) {
            const userDoc = querySnapshot.docs[0];
            
            // Delete user document
            await deleteDoc(doc(db, "users", userDoc.id));
            
            // Delete user activities if any (in subcollection)
            const activitiesSnapshot = await getDocs(collection(db, "users", userDoc.id, "activities"));
            const batch = writeBatch(db);
            
            activitiesSnapshot.forEach((activityDoc) => {
                batch.delete(doc(db, "users", userDoc.id, "activities", activityDoc.id));
            });
            
            await batch.commit();
            
            // Close modal and refresh data
            $('#deleteUserModal').modal('hide');
            loadStudentData(document.getElementById('classFilter').value);
            
            alert("Data user berhasil dihapus");
        } else {
            alert("Data user tidak ditemukan");
        }
    } catch (error) {
        console.error("Error deleting user:", error);
        alert(`Gagal menghapus user: ${error.message}`);
    }
}

export { openEditModal, saveUserEdit, openChangeClassModal, saveClassChange, openDeleteModal, confirmDelete };