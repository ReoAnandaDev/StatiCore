import { signOut, onAuthStateChanged, updateEmail, updatePassword, EmailAuthProvider, reauthenticateWithCredential } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { auth } from "./firebase-config.js";

const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes
let sessionTimeoutId;
let currentUser = null;

// Session timer management
function resetSessionTimer() {
    clearTimeout(sessionTimeoutId);
    sessionTimeoutId = setTimeout(() => {
        console.log("Session expired. Logging out...");
        signOut(auth).then(() => {
            window.location.href = "../../index.html";
        }).catch((error) => {
            console.error("Error during session timeout logout:", error);
        });
    }, SESSION_TIMEOUT);
}

// Update UI with user profile info
function updateUserProfile(user) {
    const userEmailElement = document.getElementById('userEmail');
    const userAvatarElement = document.getElementById('userAvatar');

    if (userEmailElement) {
        userEmailElement.textContent = user.email || "Email tidak tersedia";
    }
    if (userAvatarElement) {
        userAvatarElement.src = user.photoURL || "../../img/undraw_profile.svg";
    }
}

// Handle user logout
function setupLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            signOut(auth)
                .then(() => {
                    console.log("Logout berhasil");
                    window.location.href = "../../index.html";
                })
                .catch((error) => {
                    console.error("Error saat logout:", error);
                    alert("Gagal logout: " + error.message);
                });
        });
    }
}

// Initialize auth listener
function initAuth(onUserAuthenticated) {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            currentUser = user;
            updateUserProfile(user);
            setupLogout();
            
            if (typeof onUserAuthenticated === 'function') {
                onUserAuthenticated(user);
            }
        } else {
            window.location.href = "../../index.html";
        }
    });
    
    // Set up session activity listeners
    document.addEventListener("mousemove", resetSessionTimer);
    document.addEventListener("keydown", resetSessionTimer);
    document.addEventListener("click", resetSessionTimer);
}

export { initAuth, resetSessionTimer, currentUser };