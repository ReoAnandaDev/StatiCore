// Import the functions you need from the Firebase SDKs
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

// Your web app's Firebase configuration
// Replace with your actual Firebase config
const firebaseConfig = {
    apiKey: "AIzaSyCnYfcVqeNix7hyf1czx5PD6BNTR0xNdmg",
    authDomain: "tujuhebat-75d9d.firebaseapp.com",
    projectId: "tujuhebat-75d9d",
    storageBucket: "tujuhebat-75d9d.firebasestorage.app",
    messagingSenderId: "1042155779289",
    appId: "1:1042155779289:web:9ea609e5cb824d3ddf7ac8",
    measurementId: "G-BCMDF2YLBB"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

export { app, db, auth };