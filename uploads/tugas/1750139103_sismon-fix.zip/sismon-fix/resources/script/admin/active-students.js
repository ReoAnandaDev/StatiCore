// Import Firebase dependencies
import { 
    getFirestore, 
    collection, 
    query, 
    where, 
    getDocs, 
    doc, 
    getDoc, 
    Timestamp,
    onSnapshot,
    orderBy
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

export default class ActiveData {
    static currentMonth = new Date().toISOString().slice(0, 7);
    static unsubscribeFunctions = [];

    static async init() {
        const db = getFirestore();
        await this.setupFilters(db);
    }

    static async setupFilters(db) {
        const studentMonthPicker = document.querySelector("#studentMonthPicker");
        const classMonthPicker = document.querySelector("#classMonthPicker");

        if (!studentMonthPicker || !classMonthPicker) {
            console.error("Month picker elements not found in the DOM");
            return;
        }

        // Set default to current month
        const now = new Date();
        const currentMonth = now.toISOString().slice(0, 7);

        console.log("Setting default month to:", currentMonth);

        // Set initial values
        studentMonthPicker.value = currentMonth;
        classMonthPicker.value = currentMonth;
        this.currentMonth = currentMonth;

        // Initial load
        this.setupRealTimeListeners(db, currentMonth);

        // Event listeners for synchronized month changes
        studentMonthPicker.addEventListener("change", () => {
            const selectedMonth = studentMonthPicker.value;
            this.currentMonth = selectedMonth;
            classMonthPicker.value = selectedMonth; // Update class month picker
            this.setupRealTimeListeners(db, selectedMonth);
        });

        classMonthPicker.addEventListener("change", () => {
            const selectedMonth = classMonthPicker.value;
            this.currentMonth = selectedMonth;
            studentMonthPicker.value = selectedMonth; // Update student month picker
            this.setupRealTimeListeners(db, selectedMonth);
        });
    }

    static setupRealTimeListeners(db, selectedMonth) {
        // Clean up previous listeners
        this.unsubscribeFunctions.forEach(unsubscribe => unsubscribe());
        this.unsubscribeFunctions = [];

        // Calculate date range for the selected month
        const [year, month] = selectedMonth.split("-");
        const startDate = new Date(parseInt(year), parseInt(month) - 1, 1);
        const endDate = new Date(parseInt(year), parseInt(month), 0, 23, 59, 59);

        console.log("Date range:", {
            start: startDate.toISOString(),
            end: endDate.toISOString()
        });

        // Setup real-time listener for activities
        const activitiesQuery = query(
            collection(db, "activities"),
            where("validated", "==", true),
            where("createdAt", ">=", Timestamp.fromDate(startDate)),
            where("createdAt", "<=", Timestamp.fromDate(endDate)),
            orderBy("createdAt", "desc")
        );

        const unsubscribeActivities = onSnapshot(activitiesQuery, async (snapshot) => {
            try {
                console.log("Activities updated, refreshing data...");
                await this.processAndRenderData(db, snapshot, selectedMonth);
            } catch (error) {
                console.error("Error processing real-time update:", error);
            }
        });

        this.unsubscribeFunctions.push(unsubscribeActivities);
    }

    static async processAndRenderData(db, activitiesSnapshot, selectedMonth) {
        // Process students data
        const studentActivityCounts = {};
        const classActivityCounts = {};

        // Aggregate activities by student and class
        for (const activityDoc of activitiesSnapshot.docs) {
            const activity = activityDoc.data();
            const userId = activity.userId;
            if (!userId) continue;

            // Get user details
            const userDoc = await getDoc(doc(db, "users", userId));
            if (!userDoc.exists() || userDoc.data().role !== "student") continue;

            const student = userDoc.data();
            const classId = student.class;

            // Update student counts
            studentActivityCounts[userId] = (studentActivityCounts[userId] || 0) + 1;

            // Update class counts
            if (classId) {
                classActivityCounts[classId] = (classActivityCounts[classId] || 0) + 1;
            }
        }

        // Process and render student data
        const studentData = [];
        for (const userId in studentActivityCounts) {
            const userDoc = await getDoc(doc(db, "users", userId));
            const student = userDoc.data();
            let className = "Unknown";
            
            if (student.class) {
                const classDoc = await getDoc(doc(db, "classes", student.class));
                if (classDoc.exists()) {
                    className = classDoc.data().className;
                }
            }

            studentData.push({
                name: student.name || "Nama Tidak Tersedia",
                className: className,
                activityCount: studentActivityCounts[userId]
            });
        }

        // Process and render class data
        const classData = [];
        for (const classId in classActivityCounts) {
            const classDoc = await getDoc(doc(db, "classes", classId));
            if (classDoc.exists()) {
                classData.push({
                    className: classDoc.data().className,
                    activityCount: classActivityCounts[classId]
                });
            }
        }

        // Sort and render data
        studentData.sort((a, b) => b.activityCount - a.activityCount);
        classData.sort((a, b) => b.activityCount - a.activityCount);

        this.renderTable(
            studentData.slice(0, 10),
            ".active-students-container",
            ["Nama Siswa", "Kelas", "Jumlah Aktivitas"],
            ["name", "className", "activityCount"]
        );

        this.renderTable(
            classData.slice(0, 10),
            ".active-classes-container",
            ["Nama Kelas", "Jumlah Aktivitas"],
            ["className", "activityCount"]
        );
    }

    static renderTable(data, containerSelector, headers, fields) {
        const container = document.querySelector(containerSelector);
        if (!container) {
            console.error(`Container ${containerSelector} not found`);
            return;
        }

        if (data.length === 0) {
            container.innerHTML = "<h6>Tidak ada data yang tersedia</h6>";
            return;
        }

        let tableHTML = `
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            ${headers.map(header => `<th>${header}</th>`).join('')}
                        </tr>
                    </thead>
                    <tbody>
        `;

        data.forEach(item => {
            tableHTML += '<tr>';
            fields.forEach(field => {
                tableHTML += `<td>${item[field]}</td>`;
            });
            tableHTML += '</tr>';
        });

        tableHTML += `
                    </tbody>
                </table>
            </div>
        `;

        container.innerHTML = tableHTML;
    }
}