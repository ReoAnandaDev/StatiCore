import { db, CacheManager } from "../../../js/firebase-config.js";
import {
  collection,
  query,
  where,
  getCountFromServer,
  enableIndexedDbPersistence,
  getDocs,
  orderBy,
  limit,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// Cache configuration
const CACHE_DURATION = 10 * 60 * 1000; // 5 minutes
const CACHE_KEYS = {
  USER_COUNT: 'userCount',
  STUDENT_COUNT: 'studentCount',
  ACTIVITY_COUNT: 'activityCount',
  VALIDATED_COUNT: 'validatedActivityCount'
};

// Retry configuration
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // 1 second

export const CardCounter = {
  // Initialize offline persistence
  async initPersistence() {
    try {
      await enableIndexedDbPersistence(db);
      console.log("Offline persistence enabled");
    } catch (err) {
      if (err.code === 'failed-precondition') {
        console.warn("Multiple tabs open, persistence can only be enabled in one tab at a time.");
      } else if (err.code === 'unimplemented') {
        console.warn("The current browser does not support persistence");
      }
    }
  },

  // Generic retry function
  async withRetry(fn, retries = MAX_RETRIES) {
    try {
      return await fn();
    } catch (error) {
      if (retries > 0) {
        console.log(`Retrying... ${retries} attempts left`);
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
        return this.withRetry(fn, retries - 1);
      }
      throw error;
    }
  },

  // Cache management
  getFromCache(key) {
    const cached = localStorage.getItem(key);
    if (!cached) return null;
    
    const { data, timestamp } = JSON.parse(cached);
    if (Date.now() - timestamp > CACHE_DURATION) {
      localStorage.removeItem(key);
      return null;
    }
    return data;
  },

  setCache(key, data) {
    localStorage.setItem(key, JSON.stringify({
      data,
      timestamp: Date.now()
    }));
  },

  // Setup real-time listeners for all data
  setupRealTimeListeners() {
    // Listener for total users
    const usersQuery = query(collection(db, "users"));
    this.unsubscribeUsers = onSnapshot(usersQuery, async (snapshot) => {
      try {
        const count = snapshot.size;
        console.log("Total users updated:", count);
        this.setCache(CACHE_KEYS.USER_COUNT, count);
        this.updateUserCount(count);
      } catch (error) {
        console.error("Error updating total users:", error);
        this.handleError("userCount", error);
      }
    });

    // Listener for students
    const studentsQuery = query(
      collection(db, "users"),
      where("role", "==", "student")
    );
    this.unsubscribeStudents = onSnapshot(studentsQuery, async (snapshot) => {
      try {
        const count = snapshot.size;
        console.log("Total students updated:", count);
        this.setCache(CACHE_KEYS.STUDENT_COUNT, count);
        this.updateStudentCount(count);
      } catch (error) {
        console.error("Error updating total students:", error);
        this.handleError("studentCount", error);
      }
    });

    // Listener for total activities
    const activitiesQuery = query(collection(db, "activities"));
    this.unsubscribeActivities = onSnapshot(activitiesQuery, async (snapshot) => {
      try {
        const count = snapshot.size;
        console.log("Total activities updated:", count);
        this.setCache(CACHE_KEYS.ACTIVITY_COUNT, count);
        this.updateActivityCount(count);
      } catch (error) {
        console.error("Error updating total activities:", error);
        this.handleError("activityCount", error);
      }
    });

    // Listener for validated activities
    const validatedQuery = query(
      collection(db, "activities"),
      where("validated", "==", true)
    );
    this.unsubscribeValidated = onSnapshot(validatedQuery, async (snapshot) => {
      try {
        const count = snapshot.size;
        console.log("Validated activities updated:", count);
        this.setCache(CACHE_KEYS.VALIDATED_COUNT, count);
        this.updateValidatedActivityCount(count);
      } catch (error) {
        console.error("Error updating validated activities:", error);
        this.handleError("validatedActivityCount", error);
      }
    });
  },

  // Helper method to update DOM
  updateUserCount(count) {
    const userCountElement = document.getElementById('userCount');
    if (userCountElement) {
      userCountElement.textContent = count;
      userCountElement.parentElement.classList.add('loaded');
    } else {
      console.error(`Element with ID userCount not found.`);
    }
  },

  updateStudentCount(count) {
    const studentCountElement = document.getElementById('studentCount');
    if (studentCountElement) {
      studentCountElement.textContent = count;
      studentCountElement.parentElement.classList.add('loaded');
    } else {
      console.error(`Element with ID studentCount not found.`);
    }
  },

  updateActivityCount(count) {
    const activityCountElement = document.getElementById('activityCount');
    if (activityCountElement) {
      activityCountElement.textContent = count;
      activityCountElement.parentElement.classList.add('loaded');
    } else {
      console.error(`Element with ID activityCount not found.`);
    }
  },

  updateValidatedActivityCount(count) {
    const validatedActivityCountElement = document.getElementById('validatedActivityCount');
    if (validatedActivityCountElement) {
      validatedActivityCountElement.textContent = count;
      validatedActivityCountElement.parentElement.classList.add('loaded');
    } else {
      console.error(`Element with ID validatedActivityCount not found.`);
    }
  },

  // Error handling with fallback to cached data
  handleError(elementId, error) {
    console.error(`Error updating ${elementId}:`, error);
    const element = document.getElementById(elementId);
    if (element) {
      // Try to get cached data as fallback
      const cacheKey = Object.entries(CACHE_KEYS).find(([_, value]) => value === elementId)?.[0];
      if (cacheKey) {
        const cachedData = this.getFromCache(cacheKey);
        if (cachedData !== null) {
          element.textContent = cachedData;
          return;
        }
      }
      element.textContent = "Error";
      element.style.color = "red";
    }
  },

  // Initialize all counters with offline persistence
  async init() {
    try {
      // Setup real-time listeners
      this.setupRealTimeListeners();
      
      // Initial load from cache if available
      this.loadFromCache();
    } catch (error) {
      console.error("Error initializing CardCounter:", error);
    }
  },

  loadFromCache() {
    // Load user count
    const cachedUserCount = this.getFromCache(CACHE_KEYS.USER_COUNT);
    if (cachedUserCount !== null) {
      this.updateUserCount(cachedUserCount);
    }

    // Load student count
    const cachedStudentCount = this.getFromCache(CACHE_KEYS.STUDENT_COUNT);
    if (cachedStudentCount !== null) {
      this.updateStudentCount(cachedStudentCount);
    }

    // Load activity count
    const cachedActivityCount = this.getFromCache(CACHE_KEYS.ACTIVITY_COUNT);
    if (cachedActivityCount !== null) {
      this.updateActivityCount(cachedActivityCount);
    }

    // Load validated activity count
    const cachedValidatedCount = this.getFromCache(CACHE_KEYS.VALIDATED_COUNT);
    if (cachedValidatedCount !== null) {
      this.updateValidatedActivityCount(cachedValidatedCount);
    }
  },

  cleanup() {
    // Unsubscribe from all listeners
    if (this.unsubscribeUsers) this.unsubscribeUsers();
    if (this.unsubscribeStudents) this.unsubscribeStudents();
    if (this.unsubscribeActivities) this.unsubscribeActivities();
    if (this.unsubscribeValidated) this.unsubscribeValidated();
  }
};

export default CardCounter;