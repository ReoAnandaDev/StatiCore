// activity-details.js
import { db } from "../../../js/firebase-config";
import { doc, collection, query, getDocs, where, updateDoc, deleteField, Timestamp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// Function to open the activity details modal
async function openActivityDetailsModal(uid) {
    try {
        // Set the current user ID in the modal
        document.getElementById('studentUid').value = uid;
        
        // Load activity data
        await loadActivityData(uid);
        
        // Initialize the month filter
        initializeMonthFilter();
        
        // Show the modal
        $('#activityDetailsModal').modal('show');
    } catch (error) {
        console.error("Error opening activity details modal:", error);
        alert(`Gagal membuka detail aktivitas: ${error.message}`);
    }
}

// Function to initialize the month filter dropdown
function initializeMonthFilter() {
    const monthFilter = document.getElementById('activityMonthFilter');
    
    // Clear existing options except the first one (All/Semua)
    while (monthFilter.options.length > 1) {
        monthFilter.remove(1);
    }
    
    // Create an array of months
    const months = [
        {value: 0, text: 'Januari'},
        {value: 1, text: 'Februari'},
        {value: 2, text: 'Maret'},
        {value: 3, text: 'April'},
        {value: 4, text: 'Mei'},
        {value: 5, text: 'Juni'},
        {value: 6, text: 'Juli'},
        {value: 7, text: 'Agustus'},
        {value: 8, text: 'September'},
        {value: 9, text: 'Oktober'},
        {value: 10, text: 'November'},
        {value: 11, text: 'Desember'}
    ];
    
    // Get the current year
    const currentYear = new Date().getFullYear();
    
    // Add options for current year and previous year
    for (let year = currentYear; year >= currentYear - 1; year--) {
        months.forEach(month => {
            const option = document.createElement('option');
            option.value = `${year}-${month.value}`;
            option.textContent = `${month.text} ${year}`;
            monthFilter.appendChild(option);
        });
    }
}

// Function to load activity data
async function loadActivityData(uid, monthFilter = '') {
    try {
        const activityTable = document.getElementById('activityTable');
        const tableBody = activityTable.querySelector('tbody');
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Memuat data...</td></tr>';
        
        // Get activities subcollection
        const activitiesRef = collection(db, "users", uid, "activities");
        let activitiesQuery = activitiesRef;
        
        // Apply month filter if selected
        if (monthFilter) {
            const [year, month] = monthFilter.split('-').map(Number);
            
            // Create date range for the selected month
            const startDate = new Date(year, month, 1);
            const endDate = new Date(year, month + 1, 0, 23, 59, 59, 999);
            
            // Convert to Firebase Timestamp
            const startTimestamp = Timestamp.fromDate(startDate);
            const endTimestamp = Timestamp.fromDate(endDate);
            
            // Update the query with the date filter
            activitiesQuery = query(
                activitiesRef,
                where("createdAt", ">=", startTimestamp),
                where("createdAt", "<=", endTimestamp)
            );
        }
        
        const activitiesSnapshot = await getDocs(activitiesQuery);
        
        // Clear table body
        tableBody.innerHTML = '';
        
        // Check if there are activities
        if (activitiesSnapshot.empty) {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Tidak ada data aktivitas</td></tr>';
            return;
        }
        
        // Populate table with activities
        activitiesSnapshot.docs.forEach((activityDoc, index) => {
            const activityData = activityDoc.data();
            const row = document.createElement('tr');
            
            // Format timestamp
            const timestamp = activityData.createdAt?.toDate() || new Date();
            const formattedTime = new Intl.DateTimeFormat('id-ID', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            }).format(timestamp);
            
            // Determine validation status
            const isValidated = activityData.validated === true;
            const validationBtnText = isValidated ? 'Batalkan Validasi' : 'Validasi';
            const validationBtnClass = isValidated ? 'btn-danger' : 'btn-success';
            const validationAction = isValidated ? 'cancel-validation' : 'validate';
            
            // Prepare image HTML
            let imageHtml = 'Tidak ada gambar';
            if (activityData.imageBase64) {
                imageHtml = `<img src="${activityData.imageBase64}" class="img-thumbnail" style="max-height: 100px;" alt="Activity Image">`;
            }
            
            // Build row HTML
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${activityData.activityType || 'Tidak ada data'}</td>
                <td>${formattedTime}</td>
                <td>${activityData.duration || '-'}</td>
                <td>${activityData.location || 'Tidak ada data'}</td>
                <td>${imageHtml}</td>
                <td>
                    <div class="dropdown">
                        <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                            Aksi
                        </button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item activity-validation-btn ${validationBtnClass}" href="#" 
                               data-activity-id="${activityDoc.id}" 
                               data-action="${validationAction}">
                                ${validationBtnText}
                            </a>
                        </div>
                    </div>
                </td>
            `;
            
            tableBody.appendChild(row);
        });
        
        // Add event listeners to validation buttons
        document.querySelectorAll('.activity-validation-btn').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const activityId = this.getAttribute('data-activity-id');
                const action = this.getAttribute('data-action');
                
                if (action === 'validate') {
                    validateActivity(uid, activityId);
                } else {
                    cancelValidation(uid, activityId);
                }
            });
        });
        
    } catch (error) {
        console.error("Error loading activity data:", error);
        const tableBody = document.getElementById('activityTable').querySelector('tbody');
        tableBody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Gagal memuat data: ${error.message}</td></tr>`;
    }
}

// Function to validate an activity
async function validateActivity(uid, activityId) {
    try {
        const activityRef = doc(db, "users", uid, "activities", activityId);
        
        // Create current timestamp
        const now = new Date();
        const validatedAt = Timestamp.fromDate(now);
        
        // Update the document
        await updateDoc(activityRef, {
            validated: true,
            validatedAt: validatedAt
        });
        
        // Refresh the activity data
        const monthFilter = document.getElementById('activityMonthFilter').value;
        await loadActivityData(uid, monthFilter);
        
        alert("Aktivitas berhasil divalidasi");
    } catch (error) {
        console.error("Error validating activity:", error);
        alert(`Gagal memvalidasi aktivitas: ${error.message}`);
    }
}

// Function to cancel validation
async function cancelValidation(uid, activityId) {
    try {
        const activityRef = doc(db, "users", uid, "activities", activityId);
        
        // Remove validation fields
        await updateDoc(activityRef, {
            validated: deleteField(),
            validatedAt: deleteField()
        });
        
        // Refresh the activity data
        const monthFilter = document.getElementById('activityMonthFilter').value;
        await loadActivityData(uid, monthFilter);
        
        alert("Validasi aktivitas dibatalkan");
    } catch (error) {
        console.error("Error canceling validation:", error);
        alert(`Gagal membatalkan validasi: ${error.message}`);
    }
}

// Event listener for month filter change
document.addEventListener('DOMContentLoaded', function() {
    const monthFilter = document.getElementById('activityMonthFilter');
    if (monthFilter) {
        monthFilter.addEventListener('change', function() {
            const uid = document.getElementById('studentUid').value;
            loadActivityData(uid, this.value);
        });
    }
});

// Export functions for use in main script
export { openActivityDetailsModal };