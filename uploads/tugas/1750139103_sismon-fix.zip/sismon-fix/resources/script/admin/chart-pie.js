// Import Firebase dependencies
import { getFirestore, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

export default class ChartPie {
    static async init() {
        const db = getFirestore();
        const activitiesCollection = collection(db, "activities");

        // Ambil elemen input month picker
        const monthPicker = document.getElementById("pieMonthPicker");

        // Set nilai default ke bulan saat ini
        const currentMonth = this.getCurrentMonth();
        monthPicker.value = currentMonth;

        // Render chart untuk bulan saat ini
        await this.updateChart(currentMonth);

        // Tambahkan event listener untuk mendeteksi perubahan bulan
        monthPicker.addEventListener("change", async (event) => {
            const selectedMonth = event.target.value;
            await this.updateChart(selectedMonth);
        });
    }

    static getCurrentMonth() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, "0"); // Bulan dimulai dari 0, jadi tambahkan 1
        return `${year}-${month}`;
    }

    static async updateChart(selectedMonth) {
        const db = getFirestore();
        const activitiesCollection = collection(db, "activities");

        try {
            // Pisahkan tahun dan bulan dari nilai input
            const [year, month] = selectedMonth.split("-");

            // Buat query untuk mendapatkan data aktivitas berdasarkan createdAt
            const startDate = new Date(parseInt(year), parseInt(month) - 1, 1); // Awal bulan
            const endDate = new Date(parseInt(year), parseInt(month), 0); // Akhir bulan

            const q = query(
                activitiesCollection,
                where("createdAt", ">=", startDate),
                where("createdAt", "<=", endDate)
            );

            // Ambil data dari Firestore
            const querySnapshot = await getDocs(q);
            const activityCounts = {};

            querySnapshot.forEach((doc) => {
                const activityType = doc.data().activityType;
                if (activityCounts[activityType]) {
                    activityCounts[activityType]++;
                } else {
                    activityCounts[activityType] = 1;
                }
            });

            // Konversi data menjadi format Chart.js
            const labels = Object.keys(activityCounts);
            const data = Object.values(activityCounts);

            // Warna untuk setiap aktivitas (sesuai HTML)
            const backgroundColors = this.getActivityColors(labels, "backgroundColor");
            const hoverBackgroundColors = this.getActivityColors(labels, "hoverBackgroundColor");

            // Render chart atau tampilkan pesan jika tidak ada data
            if (labels.length === 0 || data.length === 0) {
                this.renderNoDataMessage();
            } else {
                this.renderPieChart(labels, data, backgroundColors, hoverBackgroundColors);
            }
        } catch (error) {
            console.error("Error fetching data from Firestore:", error);
            alert("Gagal memuat data aktivitas");
        }
    }

    static getActivityColors(labels, type) {
        // Mapping warna berdasarkan aktivitas
        const colorMapping = {
            "Bangun Pagi": "#f94144",
            "Ibadah": "#abc4ff",
            "Olahraga": "#f8961e",
            "Makanan Bergizi": "#f9c74f",
            "Belajar": "#90be6d",
            "Bersosialisasi": "#ccd904",
            "Istirahat": "blueviolet"
        };

        // Tentukan warna background atau hover background
        return labels.map(label => {
            if (type === "backgroundColor") {
                return colorMapping[label];
            } else if (type === "hoverBackgroundColor") {
                // Ubah sedikit warna hover untuk efek visual
                const baseColor = colorMapping[label];
                return this.darkenColor(baseColor, 0.2); // Gelapkan warna hover sebesar 20%
            }
        });
    }

    static darkenColor(color, amount) {
        // Fungsi untuk menggelapkan warna
        const colorObj = this.hexToRgb(color);
        if (!colorObj) return color;

        const { r, g, b } = colorObj;
        const darkenedR = Math.max(0, Math.floor(r * (1 - amount)));
        const darkenedG = Math.max(0, Math.floor(g * (1 - amount)));
        const darkenedB = Math.max(0, Math.floor(b * (1 - amount)));

        return `rgb(${darkenedR}, ${darkenedG}, ${darkenedB})`;
    }

    static hexToRgb(hex) {
        // Fungsi untuk mengonversi warna HEX ke RGB
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result
            ? {
                  r: parseInt(result[1], 16),
                  g: parseInt(result[2], 16),
                  b: parseInt(result[3], 16)
              }
            : null;
    }

    static renderPieChart(labels, data, backgroundColors, hoverBackgroundColors) {
        const ctx = document.getElementById("myPieChart").getContext("2d");

        // Hapus chart sebelumnya jika ada
        if (window.myPieChart && typeof window.myPieChart.destroy === "function") {
            window.myPieChart.destroy();
        }

        // Render chart baru
        window.myPieChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: backgroundColors,
                    hoverBackgroundColor: hoverBackgroundColors,
                    hoverBorderColor: "rgba(234, 236, 244, 1)",
                }],
            },
            options: {
                maintainAspectRatio: false,
                tooltips: {
                    backgroundColor: "rgb(255,255,255)",
                    bodyFontColor: "#858796",
                    borderColor: '#dddfeb',
                    borderWidth: 1,
                    xPadding: 15,
                    yPadding: 15,
                    displayColors: false,
                    caretPadding: 10,
                },
                legend: {
                    display: false
                },
                cutoutPercentage: 80,
            },
        });
    }

    static renderNoDataMessage() {
        const ctx = document.getElementById("myPieChart").getContext("2d");

        // Hapus chart sebelumnya jika ada
        if (window.myPieChart && typeof window.myPieChart.destroy === "function") {
            window.myPieChart.destroy();
        }

        // Gambar pesan "Tidak ada data untuk ditampilkan"
        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height); // Bersihkan canvas
        ctx.font = "16px Arial";
        ctx.fillStyle = "#000"; // Warna teks hitam
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const centerX = ctx.canvas.width / 2;
        const centerY = ctx.canvas.height / 2;
        ctx.fillText("Tidak ada data untuk ditampilkan", centerX, centerY);
    }
}