// Import Firebase dependencies
import { getFirestore, collection, query, where, orderBy, getDocs, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

export default class ChartData {
    static async init() {
        const db = getFirestore();
        const activitiesCollection = collection(db, "activities");
        const classCollection = collection(db, "classes");

        // Ambil elemen input date picker dan dropdown filter aktivitas
        const fromDateInput = document.getElementById("MulaiDate");
        const toDateInput = document.getElementById("toDate");
        const activityFilter = document.getElementById("activityFilter");
        const classFilter = document.getElementById("classFilter");

        // Set nilai default ke 7 hari ke belakang hingga hari ini
        const [defaultStartDate, defaultEndDate] = this.getLast7DaysRange();
        fromDateInput.value = this.formatDate(defaultStartDate);
        toDateInput.value = this.formatDate(defaultEndDate);

        // Inisialisasi Flatpickr
        this.initializeFlatpickr(fromDateInput, toDateInput);

        // Populasi dropdown kelas
        await this.populateClassDropdown(classFilter);

        // Render chart untuk rentang default dan filter aktivitas "all"
        await this.updateChart(defaultStartDate, defaultEndDate, "all", "all");

        // Tambahkan event listener untuk mendeteksi perubahan rentang tanggal
        fromDateInput.addEventListener("change", async () => {
            const startDate = new Date(fromDateInput.value);
            const endDate = new Date(toDateInput.value);
            const filterType = activityFilter.value;
            const selectedClass = classFilter.value;
            await this.updateChart(startDate, endDate, filterType, selectedClass);
        });

        toDateInput.addEventListener("change", async () => {
            const startDate = new Date(fromDateInput.value);
            const endDate = new Date(toDateInput.value);
            const filterType = activityFilter.value;
            const selectedClass = classFilter.value;
            await this.updateChart(startDate, endDate, filterType, selectedClass);
        });

        // Tambahkan event listener untuk dropdown filter aktivitas
        activityFilter.addEventListener("change", async () => {
            const startDate = new Date(fromDateInput.value);
            const endDate = new Date(toDateInput.value);
            const filterType = activityFilter.value;
            const selectedClass = classFilter.value;
            await this.updateChart(startDate, endDate, filterType, selectedClass);
        });

        // Tambahkan event listener untuk dropdown filter kelas
        classFilter.addEventListener("change", async () => {
            const startDate = new Date(fromDateInput.value);
            const endDate = new Date(toDateInput.value);
            const filterType = activityFilter.value;
            const selectedClass = classFilter.value;
            await this.updateChart(startDate, endDate, filterType, selectedClass);
        });
    }

    static async populateClassDropdown(classFilter) {
        try {
            const db = getFirestore();
            const classCollection = collection(db, "classes");
            const classSnapshot = await getDocs(classCollection);
            
            // Bersihkan dropdown kecuali opsi "all"
            while (classFilter.options.length > 1) {
                classFilter.remove(1);
            }
            
            // Tambahkan opsi kelas
            classSnapshot.forEach(doc => {
                const className = doc.data().className || doc.id;
                const option = document.createElement("option");
                option.value = doc.id;
                option.textContent = className;
                classFilter.appendChild(option);
            });
        } catch (error) {
            console.error("Error populating class dropdown:", error);
        }
    }

    static getLast7DaysRange() {
        const now = new Date();
        const startOfRange = new Date(now.setDate(now.getDate() - 6)); // 7 hari ke belakang
        const endOfRange = new Date(); // Hari ini
        return [startOfRange, endOfRange];
    }

    static formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }

    static initializeFlatpickr(fromDateInput, toDateInput) {
        // Inisialisasi Flatpickr untuk input "MulaiDate"
        flatpickr(fromDateInput, {
            enableTime: false,
            dateFormat: "Y-m-d",
            maxDate: "today", // Tidak boleh lebih dari hari ini
            onClose: function (selectedDates, dateStr, instance) {
                if (selectedDates.length > 0) {
                    const selectedDate = selectedDates[0];
                    const minEndDate = new Date(selectedDate).fp_incr(6); // Minimal 7 hari dari tanggal awal
                    const maxEndDate = new Date(selectedDate).fp_incr(29); // Maksimal 30 hari dari tanggal awal
                    // Update konfigurasi Flatpickr untuk toDateInput
                    flatpickr(toDateInput, {
                        enableTime: false,
                        dateFormat: "Y-m-d",
                        minDate: minEndDate,
                        maxDate: maxEndDate,
                        onClose: function (selectedDates, dateStr, instance) {
                            if (selectedDates.length > 0 && new Date(dateStr) < new Date(fromDateInput.value)) {
                                alert("Tanggal akhir tidak boleh lebih kecil dari tanggal mulai.");
                                instance.clear();
                            }
                        },
                    });
                }
            },
        });

        // Inisialisasi Flatpickr untuk input "toDate" (default)
        flatpickr(toDateInput, {
            enableTime: false,
            dateFormat: "Y-m-d",
            minDate: this.formatDate(new Date()), // Default minimal hari ini
            maxDate: new Date().fp_incr(29), // Maksimal 30 hari dari hari ini
        });
    }

    static async updateChart(startDate, endDate, filterType, selectedClass = "all") {
        // Show loading spinner
        const loadingElement = document.getElementById("areaChartLoading");
        if (loadingElement) {
            loadingElement.style.display = "flex";
        }
        
        // Sesuaikan tanggal akhir untuk mencakup seluruh hari
        const adjustedEndDate = new Date(endDate);
        adjustedEndDate.setHours(23, 59, 59, 999); // Set ke 23:59:59.999
        
        console.log("Tanggal mulai:", startDate);
        console.log("Tanggal akhir (disesuaikan):", adjustedEndDate);
        console.log("Filter:", filterType);
        console.log("Kelas:", selectedClass);
        
        const db = getFirestore();
        const activitiesCollection = collection(db, "activities");
        const classCollection = collection(db, "classes");
    
        try {
            // Ambil semua kelas dari koleksi `classes`
            const classSnapshot = await getDocs(classCollection);
            const classes = classSnapshot.docs.map(doc => ({
                id: doc.id, // ID dokumen
                name: doc.data().className || doc.id // Gunakan field `className` jika ada, atau fallback ke ID
            }));
            
            let activities = [];
            
            // Buat query berdasarkan filter
            if (filterType === "approved") {
                const approvedQuery = query(
                    activitiesCollection,
                    where("createdAt", ">=", startDate),
                    where("createdAt", "<=", adjustedEndDate),
                    where("validated", "==", true),
                    orderBy("createdAt")
                );
                const approvedSnapshot = await getDocs(approvedQuery);
                activities = approvedSnapshot.docs;
            } else if (filterType === "unapproved") {
                // Query untuk validated == false
                const falseValidatedQuery = query(
                    activitiesCollection,
                    where("createdAt", ">=", startDate),
                    where("createdAt", "<=", adjustedEndDate),
                    where("validated", "==", false),
                    orderBy("createdAt")
                );
                const falseValidatedSnapshot = await getDocs(falseValidatedQuery);
                
                // Query untuk validated == null
                const nullValidatedQuery = query(
                    activitiesCollection,
                    where("createdAt", ">=", startDate),
                    where("createdAt", "<=", adjustedEndDate),
                    where("validated", "==", null),
                    orderBy("createdAt")
                );
                const nullValidatedSnapshot = await getDocs(nullValidatedQuery);
                
                // Gabungkan hasilnya
                activities = [...falseValidatedSnapshot.docs, ...nullValidatedSnapshot.docs];
            } else {
                // "all" - semua aktivitas
                const allQuery = query(
                    activitiesCollection,
                    where("createdAt", ">=", startDate),
                    where("createdAt", "<=", adjustedEndDate),
                    orderBy("createdAt")
                );
                const allSnapshot = await getDocs(allQuery);
                activities = allSnapshot.docs;
            }
            
            console.log("Jumlah aktivitas ditemukan:", activities.length);
    
            // Generate semua tanggal dalam rentang
            const allDatesInRange = this.generateDateRange(startDate, adjustedEndDate);
            const labels = allDatesInRange.map(date => this.formatDate(date));
    
            // Hitung total aktivitas per hari
            const dailyActivityCounts = {};
            // Inisialisasi semua tanggal dengan nilai 0
            labels.forEach(dateKey => {
                dailyActivityCounts[dateKey] = 0;
            });
            
            // Buat struktur data untuk aktivitas per kelas
            const classActivityCounts = {};
            for (const cls of classes) {
                classActivityCounts[cls.id] = {}; // Inisialisasi objek untuk setiap kelas
                // Inisialisasi semua tanggal dengan nilai 0 untuk setiap kelas
                labels.forEach(dateKey => {
                    classActivityCounts[cls.id][dateKey] = 0;
                });
            }
    
            // Debug: log data aktivitas sebelum diolah
            console.log("Activities sebelum diolah:", activities.length);
            
            // Iterasi melalui setiap aktivitas
            for (const activityDoc of activities) {
                const activity = activityDoc.data();
                const userId = activity.userId;
                const createdAt = activity.createdAt.toDate();
                const dateKey = this.formatDate(createdAt);
                
                // Ambil kelas pengguna dari koleksi `users`
                const userDocRef = doc(db, "users", userId);
                const userDoc = await getDoc(userDocRef);
                
                if (userDoc.exists()) {
                    const userClass = userDoc.data().class;
                    
                    // Filter berdasarkan kelas jika tidak memilih "all"
                    if (selectedClass !== "all" && userClass !== selectedClass) {
                        continue; // Skip jika tidak cocok dengan kelas yang dipilih
                    }
                    
                    // Increment total count untuk tanggal ini
                    dailyActivityCounts[dateKey]++;
                    
                    // Log untuk debugging
                    console.log(`Aktivitas ditemukan: UserID=${userId}, tanggal=${dateKey}, count=${dailyActivityCounts[dateKey]}`);
                    
                    if (userClass && classes.some(cls => cls.id === userClass)) {
                        // Increment class count untuk tanggal ini
                        classActivityCounts[userClass][dateKey]++;
                        
                        // Log untuk debugging
                        console.log(`Aktivitas untuk kelas: Class=${userClass}, tanggal=${dateKey}, count=${classActivityCounts[userClass][dateKey]}`);
                    }
                }
            }
    
            // Data untuk total aktivitas keseluruhan
            const totalData = labels.map(date => dailyActivityCounts[date]);
    
            // Render chart dengan data total dan per kelas
            const datasets = [];
            
            // Jika "all" kelas dipilih, tampilkan total dan semua dataset kelas
            if (selectedClass === "all") {
                // Tambahkan dataset total aktivitas
                datasets.push({
                    label: "Total Aktivitas",
                    data: totalData,
                    backgroundColor: "rgba(78, 115, 223, 0.2)",
                    borderColor: "#4e73df",
                    borderWidth: 2,
                    pointRadius: 3,
                    pointBackgroundColor: "#4e73df",
                    pointBorderColor: "#fff",
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: "#4e73df",
                    pointHoverBorderColor: "#fff",
                    hidden: false
                });
                
                // Tambahkan dataset untuk setiap kelas
                for (const cls of classes) {
                    const classData = labels.map(date => classActivityCounts[cls.id][date]);
                    datasets.push({
                        label: cls.name,
                        data: classData,
                        borderColor: this.getRandomColor(),
                        borderWidth: 2,
                        pointRadius: 3,
                        pointBackgroundColor: this.getRandomColor(),
                        pointHoverRadius: 5,
                        pointHoverBackgroundColor: this.getRandomColor(),
                        hidden: true
                    });
                }
            } else {
                // Jika kelas spesifik dipilih, tampilkan hanya dataset dari kelas tersebut
                const selectedClassObj = classes.find(cls => cls.id === selectedClass);
                if (selectedClassObj) {
                    const classData = labels.map(date => classActivityCounts[selectedClass][date]);
                    datasets.push({
                        label: selectedClassObj.name,
                        data: classData,
                        backgroundColor: "rgba(78, 115, 223, 0.2)",
                        borderColor: "#4e73df",
                        borderWidth: 2,
                        pointRadius: 3,
                        pointBackgroundColor: "#4e73df",
                        pointBorderColor: "#fff",
                        pointHoverRadius: 5,
                        pointHoverBackgroundColor: "#4e73df",
                        pointHoverBorderColor: "#fff",
                        hidden: false
                    });
                }
            }
    
            // Debug: log datasets sebelum render
            console.log("Datasets untuk chart:", datasets);
    
            // Render chart atau tampilkan pesan jika tidak ada data
            if (datasets.every(dataset => dataset.data.every(count => count === 0))) {
                this.renderNoDataMessage();
            } else {
                this.renderAreaChart(labels, datasets);
            }
        } catch (error) {
            console.error("Error fetching data from Firestore:", error);
            console.log("Error details:", error.message, error.code);
            alert("Gagal memuat data aktivitas: " + error.message);
        } finally {
            // Hide loading spinner
            if (loadingElement) {
                loadingElement.style.display = "none";
            }
        }
    }

    static generateDateRange(startDate, endDate) {
        const dates = [];
        let currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            dates.push(new Date(currentDate));
            currentDate.setDate(currentDate.getDate() + 1);
        }
        return dates;
    }

    static renderAreaChart(labels, datasets) {
        const ctx = document.getElementById("myAreaChart").getContext("2d");

        // Hapus chart sebelumnya jika ada
        if (window.myAreaChart && typeof window.myAreaChart.destroy === "function") {
            window.myAreaChart.destroy();
        }

        // Hapus isi dataset[0] dari datasets untuk mencegah tampilan legenda
        const firstDataset = datasets[0];
        datasets = [firstDataset]; // Hanya tampilkan dataset pertama

        // Render chart baru
        window.myAreaChart = new Chart(ctx, {
            type: "line",
            data: {
                labels: labels,
                datasets: datasets,
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { maxTicksLimit: 10 },
                    },
                    y: {
                        beginAtZero: true,
                        afterBuildTicks: (scale) => {
                            const maxData = Math.max(...datasets.flatMap(dataset => dataset.data));
                            const minData = Math.min(...datasets.flatMap(dataset => dataset.data));
                            const min = Math.floor(minData / 5) * 5;
                            const max = Math.ceil(maxData / 5) * 5;
                            const stepSize = 5;
                            const ticks = [];
                            for (let i = min; i <= max; i += stepSize) {
                                ticks.push(i);
                            }
                            scale.ticks = ticks;
                            return;
                        },
                        grid: { color: "rgba(0, 0, 0, 0.1)" },
                    },
                },
                plugins: {
                    legend: { 
                        display: false
                    },
                    tooltip: {
                        backgroundColor: "rgb(255,255,255)",
                        bodyColor: "#858796",
                        titleColor: "#6e707e",
                        borderColor: "#dddfeb",
                        borderWidth: 1,
                        caretSize: 5,
                    },
                },
            },
        });
    }

    static renderNoDataMessage() {
        const ctx = document.getElementById("myAreaChart").getContext("2d");

        // Hapus chart sebelumnya jika ada
        if (window.myAreaChart && typeof window.myAreaChart.destroy === "function") {
            window.myAreaChart.destroy();
        }

        // Gambar pesan "Tidak ada data untuk ditampilkan"
        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height); // Bersihkan canvas
        ctx.font = "16px Arial";
        ctx.fillStyle = "#858796"; // Warna abu-abu
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const centerX = ctx.canvas.width / 2;
        const centerY = ctx.canvas.height / 2;
        ctx.fillText("Tidak ada data untuk ditampilkan", centerX, centerY);
    }

    static getRandomColor() {
        const letters = "0123456789ABCDEF";
        let color = "#";
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }
}