// Import Firebase dependencies
import { 
    getFirestore, 
    collection, 
    query, 
    where, 
    getDocs, 
    doc, 
    getDoc, 
    Timestamp
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

export default class ActiveData {
    static async init() {
        const db = getFirestore();
        await this.setupFilters(db);
    }

    static async setupFilters(db) {
        const studentMonthPicker = document.querySelector("#studentMonthPicker");
        const classMonthPicker = document.querySelector("#classMonthPicker");

        // Validasi bahwa elemen DOM ditemukan
        if (!studentMonthPicker) {
            console.error("Student month picker element not found in the DOM");
            return;
        }

        // Set default to current month (UTC)
        const now = new Date();
        const currentMonthUTC = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1))
            .toISOString()
            .slice(0, 7);

        console.log("Setting default month to:", currentMonthUTC);

        // Set initial values
        studentMonthPicker.value = currentMonthUTC;
        if (classMonthPicker) {
            classMonthPicker.value = currentMonthUTC;
        }

        // Initial load
        await this.fetchAndRenderActiveStudents(db, currentMonthUTC);
        
        // Only render active classes if the element exists (might be admin-only)
        if (classMonthPicker) {
            await this.fetchAndRenderActiveClasses(db, currentMonthUTC);

            // Event listener for class month picker
            classMonthPicker.addEventListener("change", async () => {
                console.log("Class month changed to:", classMonthPicker.value);
                await this.fetchAndRenderActiveClasses(db, classMonthPicker.value);
            });
        }

        // Event listener for student month picker
        studentMonthPicker.addEventListener("change", async () => {
            console.log("Student month changed to:", studentMonthPicker.value);
            await this.fetchAndRenderActiveStudents(db, studentMonthPicker.value);
        });
    }

    static async fetchAndRenderActiveStudents(db, selectedMonth) {
        const container = document.querySelector(".active-students-container");
        if (!container) {
            console.error("Active students container not found");
            return;
        }

        try {
            console.log("Fetching active students for month:", selectedMonth);
            container.innerHTML = "<h6>Memuat data...</h6>";
            
            // 1. Get current teacher's class assignments
            const auth = getAuth();
            const currentUser = auth.currentUser;
            
            if (!currentUser) {
                console.error("No authenticated user found");
                container.innerHTML = "<h6>Memuat data...</h6>";
                return;
            }
            
            // Get the teacher's data from Firestore
            const teacherDoc = await getDoc(doc(db, "users", currentUser.uid));
            
            if (!teacherDoc.exists() || teacherDoc.data().role !== "teacher") {
                console.error("Current user is not a teacher or data not found");
                container.innerHTML = "<h6>Hanya tersedia untuk akun guru</h6>";
                return;
            }
            
            // Get the class IDs that this teacher is assigned to
            const teacherClasses = teacherDoc.data().class || [];
            
            // Handle both array and single string cases
            const teacherClassIds = Array.isArray(teacherClasses) ? teacherClasses : [teacherClasses];
            
            if (teacherClassIds.length === 0) {
                console.log("Teacher has no assigned classes");
                container.innerHTML = "<h6>Anda belum ditugaskan ke kelas manapun</h6>";
                return;
            }
            
            console.log("Teacher is assigned to classes:", teacherClassIds);
            
            // 2. Calculate date range (UTC)
            const [year, month] = selectedMonth.split("-");
            const startDate = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, 1));
            const endDate = new Date(Date.UTC(parseInt(year), parseInt(month), 0, 23, 59, 59));
            console.log("Date range for students:", startDate, "to", endDate);
    
            // 3. Get all validated activities within the date range
            const activitiesQuery = query(
                collection(db, "activities"),
                where("validated", "==", true),
                where("createdAt", ">=", Timestamp.fromDate(startDate)),
                where("createdAt", "<=", Timestamp.fromDate(endDate))
            );
            const activitiesSnapshot = await getDocs(activitiesQuery);
            console.log(`Found ${activitiesSnapshot.size} total validated activities`);
    
            // 4. Aggregate activity counts by user and filter by teacher's classes
            const studentActivityCounts = {};
            for (const activityDoc of activitiesSnapshot.docs) {
                const activity = activityDoc.data();
                const userId = activity.userId;
                if (!userId) continue;
    
                // Fetch user details to check if they are a student in one of the teacher's classes
                const userDoc = await getDoc(doc(db, "users", userId));
                if (!userDoc.exists() || 
                    userDoc.data().role !== "student" || 
                    !teacherClassIds.includes(userDoc.data().class)) {
                    continue;
                }
    
                // Aggregate activity counts
                studentActivityCounts[userId] = (studentActivityCounts[userId] || 0) + 1;
            }
    
            // 5. Get student details and class information
            const studentData = [];
            for (const userId in studentActivityCounts) {
                const userDoc = await getDoc(doc(db, "users", userId));
                const student = userDoc.data();
                let className = "Unknown";
                if (student.class) {
                    const classDoc = await getDoc(doc(db, "classes", student.class));
                    if (classDoc.exists()) {
                        className = classDoc.data().className;
                    }
                }
                studentData.push({
                    name: student.name || "Nama Tidak Tersedia",
                    className: className,
                    activityCount: studentActivityCounts[userId]
                });
            }
    
            console.log(`Found ${studentData.length} active students for the selected month`);
            
            // 6. Sort and render (highest activity count first)
            studentData.sort((a, b) => b.activityCount - a.activityCount);
            this.renderTable(
                studentData.slice(0, 10),
                ".active-students-container",
                ["Nama Siswa", "Kelas", "Jumlah Aktivitas"],
                ["name", "className", "activityCount"]
            );
        } catch (error) {
            console.error("Student Error:", error);
            container.innerHTML = `
                <div class="text-danger">
                    <h6>Gagal memuat data siswa</h6>
                    <small>${error.message}</small>
                </div>
            `;
        }
    }
    
    static async fetchAndRenderActiveClasses(db, selectedMonth) {
        // Your existing code for fetching and rendering active classes
        // ...
    }

    static renderTable(data, containerSelector, headers, fields) {
        const container = document.querySelector(containerSelector);
        if (!container) {
            console.error(`Container not found: ${containerSelector}`);
            return;
        }
        
        container.innerHTML = "";

        if (!data || !data.length) {
            container.innerHTML = "<h6>Tidak ada data untuk bulan ini</h6>";
            return;
        }

        const table = document.createElement("table");
        table.className = "table table-bordered table-hover table-striped";
        
        // Header
        const thead = document.createElement("thead");
        thead.innerHTML = `
            <tr class="bg-primary text-white">
                ${headers.map(h => `<th>${h}</th>`).join("")}
            </tr>
        `;
        
        // Body
        const tbody = document.createElement("tbody");
        data.forEach(item => {
            const tr = document.createElement("tr");
            tr.innerHTML = fields.map(field => `
                <td>${item[field]}</td>
            `).join("");
            tbody.appendChild(tr);
        });

        table.appendChild(thead);
        table.appendChild(tbody);
        container.appendChild(table);

        console.log(`Rendered table with ${data.length} rows`);
    }
}