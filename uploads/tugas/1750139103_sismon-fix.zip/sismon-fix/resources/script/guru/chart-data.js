// Import Firebase dependencies
import { getFirestore, collection, query, where, orderBy, getDocs, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

export default class ChartData {
    static async init() {
        const db = getFirestore();
        const activitiesCollection = collection(db, "activities");
        const classCollection = collection(db, "classes");

        // Ambil elemen input date picker dan dropdown filter aktivitas
        const fromDateInput = document.getElementById("MulaiDate");
        const toDateInput = document.getElementById("toDate");
        const activityFilter = document.getElementById("activityFilter");

        // Set nilai default ke 7 hari ke belakang hingga hari ini
        const [defaultStartDate, defaultEndDate] = this.getLast7DaysRange();
        fromDateInput.value = this.formatDate(defaultStartDate);
        toDateInput.value = this.formatDate(defaultEndDate);

        // Inisialisasi Flatpickr
        this.initializeFlatpickr(fromDateInput, toDateInput);

        // Dapatkan kelas yang diampu oleh guru yang login
        const teacherClass = await this.getTeacherClass();
        
        // Simpan referensi kelas guru untuk digunakan di method lain
        this.teacherClass = teacherClass;
        
        console.log("Kelas yang diampu guru:", teacherClass);

        // Render chart untuk rentang default dan filter aktivitas "all"
        await this.updateChart(defaultStartDate, defaultEndDate, "all");

        // Tambahkan event listener untuk mendeteksi perubahan rentang tanggal
        fromDateInput.addEventListener("change", async () => {
            const startDate = new Date(fromDateInput.value);
            const endDate = new Date(toDateInput.value);
            const filterType = activityFilter.value;
            await this.updateChart(startDate, endDate, filterType);
        });

        toDateInput.addEventListener("change", async () => {
            const startDate = new Date(fromDateInput.value);
            const endDate = new Date(toDateInput.value);
            const filterType = activityFilter.value;
            await this.updateChart(startDate, endDate, filterType);
        });

        // Tambahkan event listener untuk dropdown filter aktivitas
        activityFilter.addEventListener("change", async () => {
            const startDate = new Date(fromDateInput.value);
            const endDate = new Date(toDateInput.value);
            const filterType = activityFilter.value;
            await this.updateChart(startDate, endDate, filterType);
        });
    }

    static async getTeacherClass() {
        try {
            const auth = getAuth();
            const currentUser = auth.currentUser;
            
            if (!currentUser) {
                console.error("Tidak ada user yang login");
                return null;
            }
            
            const db = getFirestore();
            const userDocRef = doc(db, "users", currentUser.uid);
            const userDoc = await getDoc(userDocRef);
            
            if (userDoc.exists()) {
                const userData = userDoc.data();
                return userData.class; // ID kelas yang diampu guru
            } else {
                console.error("Data user tidak ditemukan");
                return null;
            }
        } catch (error) {
            console.error("Error mendapatkan kelas guru:", error);
            return null;
        }
    }

    static getLast7DaysRange() {
        const now = new Date();
        const startOfRange = new Date(now.setDate(now.getDate() - 6)); // 7 hari ke belakang
        const endOfRange = new Date(); // Hari ini
        return [startOfRange, endOfRange];
    }

    static formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }

    static initializeFlatpickr(fromDateInput, toDateInput) {
        // Inisialisasi Flatpickr untuk input "MulaiDate"
        flatpickr(fromDateInput, {
            enableTime: false,
            dateFormat: "Y-m-d",
            maxDate: "today", // Tidak boleh lebih dari hari ini
            onClose: function (selectedDates, dateStr, instance) {
                if (selectedDates.length > 0) {
                    const selectedDate = selectedDates[0];
                    const minEndDate = new Date(selectedDate).fp_incr(6); // Minimal 7 hari dari tanggal awal
                    const maxEndDate = new Date(selectedDate).fp_incr(29); // Maksimal 30 hari dari tanggal awal
                    // Update konfigurasi Flatpickr untuk toDateInput
                    flatpickr(toDateInput, {
                        enableTime: false,
                        dateFormat: "Y-m-d",
                        minDate: minEndDate,
                        maxDate: maxEndDate,
                        onClose: function (selectedDates, dateStr, instance) {
                            if (selectedDates.length > 0 && new Date(dateStr) < new Date(fromDateInput.value)) {
                                alert("Tanggal akhir tidak boleh lebih kecil dari tanggal mulai.");
                                instance.clear();
                            }
                        },
                    });
                }
            },
        });

        // Inisialisasi Flatpickr untuk input "toDate" (default)
        flatpickr(toDateInput, {
            enableTime: false,
            dateFormat: "Y-m-d",
            minDate: this.formatDate(new Date()), // Default minimal hari ini
            maxDate: new Date().fp_incr(29), // Maksimal 30 hari dari hari ini
        });
    }

    static async updateChart(startDate, endDate, filterType) {
        // Sesuaikan tanggal akhir untuk mencakup seluruh hari
        const adjustedEndDate = new Date(endDate);
        adjustedEndDate.setHours(23, 59, 59, 999); // Set ke 23:59:59.999
        
        console.log("Tanggal mulai:", startDate);
        console.log("Tanggal akhir (disesuaikan):", adjustedEndDate);
        console.log("Filter:", filterType);
        console.log("Kelas guru:", this.teacherClass);
        
        const db = getFirestore();
        const activitiesCollection = collection(db, "activities");
        const classCollection = collection(db, "classes");

        try {
            // Pastikan kita memiliki kelas guru
            if (!this.teacherClass) {
                console.error("Kelas guru tidak ditemukan");
                this.renderNoDataMessage("Loading..");
                return;
            }
            
            // Ambil data kelas yang diampu guru
            const classDocRef = doc(db, "classes", this.teacherClass);
            const classDoc = await getDoc(classDocRef);
            
            if (!classDoc.exists()) {
                console.error("Data kelas tidak ditemukan");
                this.renderNoDataMessage("Data kelas tidak ditemukan");
                return;
            }
            
            const classData = {
                id: classDoc.id,
                name: classDoc.data().className || classDoc.id
            };
            
            console.log("Data kelas guru:", classData);
            
            let activities = [];
            
            // Buat query berdasarkan filter
            if (filterType === "approved") {
                const approvedQuery = query(
                    activitiesCollection,
                    where("createdAt", ">=", startDate),
                    where("createdAt", "<=", adjustedEndDate),
                    where("validated", "==", true),
                    orderBy("createdAt")
                );
                const approvedSnapshot = await getDocs(approvedQuery);
                activities = approvedSnapshot.docs;
            } else if (filterType === "unapproved") {
                // Query untuk validated == false
                const falseValidatedQuery = query(
                    activitiesCollection,
                    where("createdAt", ">=", startDate),
                    where("createdAt", "<=", adjustedEndDate),
                    where("validated", "==", false),
                    orderBy("createdAt")
                );
                const falseValidatedSnapshot = await getDocs(falseValidatedQuery);
                
                // Query untuk validated == null
                const nullValidatedQuery = query(
                    activitiesCollection,
                    where("createdAt", ">=", startDate),
                    where("createdAt", "<=", adjustedEndDate),
                    where("validated", "==", null),
                    orderBy("createdAt")
                );
                const nullValidatedSnapshot = await getDocs(nullValidatedQuery);
                
                // Gabungkan hasilnya
                activities = [...falseValidatedSnapshot.docs, ...nullValidatedSnapshot.docs];
            } else {
                // "all" - semua aktivitas
                const allQuery = query(
                    activitiesCollection,
                    where("createdAt", ">=", startDate),
                    where("createdAt", "<=", adjustedEndDate),
                    orderBy("createdAt")
                );
                const allSnapshot = await getDocs(allQuery);
                activities = allSnapshot.docs;
            }
            
            console.log("Jumlah aktivitas ditemukan:", activities.length);
    
            // Generate semua tanggal dalam rentang
            const allDatesInRange = this.generateDateRange(startDate, adjustedEndDate);
            const labels = allDatesInRange.map(date => this.formatDate(date));
    
            // Hitung total aktivitas per hari
            const dailyActivityCounts = {};
            // Inisialisasi semua tanggal dengan nilai 0
            labels.forEach(dateKey => {
                dailyActivityCounts[dateKey] = 0;
            });
            
            // Inisialisasi objek untuk aktivitas kelas yang diampu guru
            const teacherClassActivityCounts = {};
            labels.forEach(dateKey => {
                teacherClassActivityCounts[dateKey] = 0;
            });
    
            // Iterasi melalui setiap aktivitas
            for (const activityDoc of activities) {
                const activity = activityDoc.data();
                const userId = activity.userId;
                const createdAt = activity.createdAt.toDate();
                const dateKey = this.formatDate(createdAt);
                
                // Ambil data pengguna untuk mengetahui kelasnya
                const userDocRef = doc(db, "users", userId);
                const userDoc = await getDoc(userDocRef);
                
                if (userDoc.exists()) {
                    const userData = userDoc.data();
                    const userClass = userData.class;
                    
                    // Increment counter total hanya jika siswa dari kelas yang diampu guru
                    if (userClass === this.teacherClass) {
                        dailyActivityCounts[dateKey]++;
                        teacherClassActivityCounts[dateKey]++;
                        
                        console.log(`Aktivitas siswa dari kelas ${classData.name}: UserID=${userId}, tanggal=${dateKey}`);
                    }
                }
            }
    
            // Data untuk total aktivitas dari kelas yang diampu guru
            const teacherClassData = labels.map(date => teacherClassActivityCounts[date]);
    
            // Render chart dengan data kelas yang diampu guru
            const datasets = [
                {
                    label: `Aktivitas Kelas ${classData.name}`,
                    data: teacherClassData,
                    backgroundColor: "rgba(78, 115, 223, 0.2)",
                    borderColor: "#4e73df",
                    borderWidth: 2,
                    pointRadius: 3,
                    pointBackgroundColor: "#4e73df",
                    pointBorderColor: "#fff",
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: "#4e73df",
                    pointHoverBorderColor: "#fff",
                }
            ];
    
            // Debug: log datasets sebelum render
            console.log("Datasets untuk chart:", datasets);
    
            // Render chart atau tampilkan pesan jika tidak ada data
            if (datasets.every(dataset => dataset.data.every(count => count === 0))) {
                this.renderNoDataMessage("Tidak ada Data");
            } else {
                this.renderAreaChart(labels, datasets);
            }
        } catch (error) {
            console.error("Error fetching data from Firestore:", error);
            console.log("Error details:", error.message, error.code);
            this.renderNoDataMessage("Error: " + error.message);
        }
    }

    static generateDateRange(startDate, endDate) {
        const dates = [];
        let currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            dates.push(new Date(currentDate));
            currentDate.setDate(currentDate.getDate() + 1);
        }
        return dates;
    }

    static renderAreaChart(labels, datasets) {
        const ctx = document.getElementById("myAreaChart").getContext("2d");

        // Hapus chart sebelumnya jika ada
        if (window.myAreaChart && typeof window.myAreaChart.destroy === "function") {
            window.myAreaChart.destroy();
        }

        // Render chart baru
        window.myAreaChart = new Chart(ctx, {
            type: "line",
            data: {
                labels: labels,
                datasets: datasets,
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { maxTicksLimit: 10 },
                    },
                    y: {
                        beginAtZero: true,
                        afterBuildTicks: (scale) => {
                            const maxData = Math.max(...datasets.flatMap(dataset => dataset.data));
                            const minData = Math.min(...datasets.flatMap(dataset => dataset.data));
                            const min = Math.floor(minData / 5) * 5;
                            const max = Math.ceil(maxData / 5) * 5;
                            const stepSize = 5;
                            const ticks = [];
                            for (let i = min; i <= max; i += stepSize) {
                                ticks.push(i);
                            }
                            scale.ticks = ticks;
                            return;
                        },
                        grid: { color: "rgba(0, 0, 0, 0.1)" },
                    },
                },
                plugins: {
                    legend: { display: true, position: "top" },
                    tooltip: {
                        backgroundColor: "rgb(255,255,255)",
                        bodyColor: "#858796",
                        titleColor: "#6e707e",
                        borderColor: "#dddfeb",
                        borderWidth: 1,
                        caretSize: 5,
                    },
                },
            },
        });
    }

    static renderNoDataMessage(message = "Tidak ada data untuk ditampilkan") {
        const ctx = document.getElementById("myAreaChart").getContext("2d");

        // Hapus chart sebelumnya jika ada
        if (window.myAreaChart && typeof window.myAreaChart.destroy === "function") {
            window.myAreaChart.destroy();
        }

        // Gambar pesan
        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height); // Bersihkan canvas
        ctx.font = "16px Arial";
        ctx.fillStyle = "#858796"; // Warna abu-abu
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const centerX = ctx.canvas.width / 2;
        const centerY = ctx.canvas.height / 2;
        ctx.fillText(message, centerX, centerY);
    }

    static getRandomColor() {
        const letters = "0123456789ABCDEF";
        let color = "#";
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }
}