import { db, auth } from "../../../js/firebase-config.js";
import {
  collection,
  getDocs,
  query,
  where,
  collectionGroup,
  doc,
  getDoc,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

export const CardCounter = {
  // Store the teacher's classes
  teacherClasses: [],
  // Store unsubscribe functions for cleanup
  unsubscribeFunctions: [],
  // Store initialization state
  isInitialized: false,

  // Set loading state for all counters
  setLoadingState() {
    const counters = ["studentCount", "activityCount", "validatedActivityCount"];
    counters.forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        element.textContent = "Loading...";
        element.classList.add('loading');
      }
    });
  },

  // Get classes taught by the logged-in teacher
  async getTeacherClasses() {
    try {
      const user = auth.currentUser;
      if (!user) {
        console.error("No user is logged in");
        return [];
      }

      const teacherDoc = await getDoc(doc(db, "users", user.uid));
      if (!teacherDoc.exists()) {
        console.error("Teacher document not found");
        return [];
      }

      const teacherData = teacherDoc.data();
      
      if (teacherData.class && Array.isArray(teacherData.class)) {
        this.teacherClasses = teacherData.class;
        return teacherData.class;
      } else if (teacherData.class) {
        this.teacherClasses = [teacherData.class];
        return [teacherData.class];
      }
      
      return [];
    } catch (error) {
      console.error("Error fetching teacher classes:", error);
      return [];
    }
  },

  // Setup real-time listener for student count
  setupStudentCountListener() {
    if (this.teacherClasses.length === 0) {
      this.updateCounter("studentCount", 0);
      return;
    }

    const q = query(
      collection(db, "users"),
      where("role", "==", "student"),
      where("class", "in", this.teacherClasses)
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      this.updateCounter("studentCount", snapshot.size);
    }, (error) => {
      this.handleError("studentCount", error);
    });

    this.unsubscribeFunctions.push(unsubscribe);
  },

  // Setup real-time listener for activity count
  setupActivityCountListener() {
    if (this.teacherClasses.length === 0) {
      this.updateCounter("activityCount", 0);
      return;
    }

    const studentsQuery = query(
      collection(db, "users"),
      where("role", "==", "student"),
      where("class", "in", this.teacherClasses)
    );

    const unsubscribe = onSnapshot(studentsQuery, async (studentsSnapshot) => {
      const studentIds = studentsSnapshot.docs.map(doc => doc.id);
      
      if (studentIds.length === 0) {
        this.updateCounter("activityCount", 0);
        return;
      }

      // Split studentIds into chunks of 10 to avoid Firestore limitations
      const chunkSize = 10;
      const chunks = [];
      for (let i = 0; i < studentIds.length; i += chunkSize) {
        chunks.push(studentIds.slice(i, i + chunkSize));
      }

      let totalActivities = 0;
      for (const chunk of chunks) {
        const activitiesQuery = query(
          collection(db, "activities"),
          where("userId", "in", chunk)
        );

        const activitiesSnapshot = await getDocs(activitiesQuery);
        totalActivities += activitiesSnapshot.size;
      }

      this.updateCounter("activityCount", totalActivities);
    }, (error) => {
      this.handleError("activityCount", error);
    });

    this.unsubscribeFunctions.push(unsubscribe);
  },

  // Setup real-time listener for validated activity count
  setupValidatedActivityCountListener() {
    if (this.teacherClasses.length === 0) {
      this.updateCounter("validatedActivityCount", 0);
      return;
    }

    const studentsQuery = query(
      collection(db, "users"),
      where("role", "==", "student"),
      where("class", "in", this.teacherClasses)
    );

    const unsubscribe = onSnapshot(studentsQuery, async (studentsSnapshot) => {
      const studentIds = studentsSnapshot.docs.map(doc => doc.id);
      
      if (studentIds.length === 0) {
        this.updateCounter("validatedActivityCount", 0);
        return;
      }

      // Split studentIds into chunks of 10 to avoid Firestore limitations
      const chunkSize = 10;
      const chunks = [];
      for (let i = 0; i < studentIds.length; i += chunkSize) {
        chunks.push(studentIds.slice(i, i + chunkSize));
      }

      let totalValidatedActivities = 0;
      for (const chunk of chunks) {
        const validatedActivitiesQuery = query(
          collection(db, "activities"),
          where("userId", "in", chunk),
          where("validated", "==", true)
        );

        const validatedActivitiesSnapshot = await getDocs(validatedActivitiesQuery);
        totalValidatedActivities += validatedActivitiesSnapshot.size;
      }

      this.updateCounter("validatedActivityCount", totalValidatedActivities);
    }, (error) => {
      this.handleError("validatedActivityCount", error);
    });

    this.unsubscribeFunctions.push(unsubscribe);
  },

  // Helper method to update DOM
  updateCounter(elementId, count) {
    const element = document.getElementById(elementId);
    if (element) {
      element.classList.remove('loading');
      element.textContent = count;
      element.parentElement.classList.add('loaded');
    }
  },

  // Error handling
  handleError(elementId, error) {
    console.error(`Error updating ${elementId}:`, error);
    const element = document.getElementById(elementId);
    if (element) {
      element.classList.remove('loading');
      element.textContent = "Error";
      element.style.color = "red";
    }
  },

  // Cleanup function to unsubscribe from all listeners
  cleanup() {
    this.unsubscribeFunctions.forEach(unsubscribe => unsubscribe());
    this.unsubscribeFunctions = [];
    this.isInitialized = false;
  },

  // Initialize all counters with real-time updates
  async init() {
    // Prevent multiple initializations
    if (this.isInitialized) {
      return;
    }

    try {
      // Wait for auth state to be ready
      await new Promise((resolve) => {
        const unsubscribe = auth.onAuthStateChanged((user) => {
          unsubscribe();
          resolve(user);
        });
      });

      // Cleanup any existing listeners
      this.cleanup();
      
      // Set loading state
      this.setLoadingState();
      
      // Get the teacher's classes
      await this.getTeacherClasses();
      
      // Setup real-time listeners
      this.setupStudentCountListener();
      this.setupActivityCountListener();
      this.setupValidatedActivityCountListener();

      this.isInitialized = true;
    } catch (error) {
      console.error("Error initializing counters:", error);
      // Update all counters to show error state
      this.handleError("studentCount", error);
      this.handleError("activityCount", error);
      this.handleError("validatedActivityCount", error);
    }
  },
};

export default CardCounter;