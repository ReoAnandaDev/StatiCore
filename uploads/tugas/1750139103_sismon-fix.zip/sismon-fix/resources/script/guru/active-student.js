import { db, auth } from "../../../js/firebase-config.js";
import {
  collection,
  query,
  where,
  doc,
  getDoc,
  onSnapshot,
  Timestamp
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

export class ActiveStudentData {
  constructor() {
    this.teacherClasses = [];
    this.unsubscribeFunctions = [];
    this.currentMonth = null;
  }

  // Set loading state
  setLoadingState() {
    const container = document.querySelector(".active-students-container");
    if (container) {
      container.innerHTML = "<h6>Loading...</h6>";
    }
  }

  // Get teacher's classes
  async getTeacherClasses() {
    try {
      const user = auth.currentUser;
      if (!user) {
        console.error("No user is logged in");
        return [];
      }

      const teacherDoc = await getDoc(doc(db, "users", user.uid));
      if (!teacherDoc.exists()) {
        console.error("Teacher document not found");
        return [];
      }

      const teacherData = teacherDoc.data();
      
      if (teacherData.class && Array.isArray(teacherData.class)) {
        this.teacherClasses = teacherData.class;
        return teacherData.class;
      } else if (teacherData.class) {
        this.teacherClasses = [teacherData.class];
        return [teacherData.class];
      }
      
      return [];
    } catch (error) {
      console.error("Error fetching teacher classes:", error);
      return [];
    }
  }

  // Setup real-time listener for active students
  async setupActiveStudentsListener(selectedMonth) {
    if (this.teacherClasses.length === 0) {
      this.renderNoData();
      return;
    }

    // Calculate date range (UTC)
    const [year, month] = selectedMonth.split("-");
    const startDate = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, 1));
    const endDate = new Date(Date.UTC(parseInt(year), parseInt(month), 0, 23, 59, 59));

    // Get all students in teacher's classes
    const studentsQuery = query(
      collection(db, "users"),
      where("role", "==", "student"),
      where("class", "in", this.teacherClasses)
    );

    const unsubscribe = onSnapshot(studentsQuery, async (studentsSnapshot) => {
      const studentIds = studentsSnapshot.docs.map(doc => doc.id);
      
      if (studentIds.length === 0) {
        this.renderNoData();
        return;
      }

      // Get validated activities for these students within the date range
      const activitiesQuery = query(
        collection(db, "activities"),
        where("userId", "in", studentIds),
        where("validated", "==", true),
        where("createdAt", ">=", Timestamp.fromDate(startDate)),
        where("createdAt", "<=", Timestamp.fromDate(endDate))
      );

      const activitiesUnsubscribe = onSnapshot(activitiesQuery, async (activitiesSnapshot) => {
        // Aggregate activity counts by user
        const studentActivityCounts = {};
        activitiesSnapshot.docs.forEach(doc => {
          const activity = doc.data();
          const userId = activity.userId;
          studentActivityCounts[userId] = (studentActivityCounts[userId] || 0) + 1;
        });

        // Get student details and class information
        const studentData = [];
        for (const userId in studentActivityCounts) {
          const userDoc = await getDoc(doc(db, "users", userId));
          const student = userDoc.data();
          let className = "Unknown";
          if (student.class) {
            const classDoc = await getDoc(doc(db, "classes", student.class));
            if (classDoc.exists()) {
              className = classDoc.data().className;
            }
          }
          studentData.push({
            name: student.name || "Nama Tidak Tersedia",
            className: className,
            activityCount: studentActivityCounts[userId]
          });
        }

        // Sort and render
        studentData.sort((a, b) => b.activityCount - a.activityCount);
        this.renderTable(
          studentData.slice(0, 10),
          ["Nama Siswa", "Kelas", "Jumlah Aktivitas"],
          ["name", "className", "activityCount"]
        );
      }, (error) => {
        this.handleError(error);
      });

      this.unsubscribeFunctions.push(activitiesUnsubscribe);
    }, (error) => {
      this.handleError(error);
    });

    this.unsubscribeFunctions.push(unsubscribe);
  }

  // Render table with data
  renderTable(data, headers, fields) {
    const container = document.querySelector(".active-students-container");
    if (!container) return;

    container.innerHTML = "";

    if (!data || !data.length) {
      this.renderNoData();
      return;
    }

    const table = document.createElement("table");
    table.className = "table table-bordered table-hover table-striped";

    // Header
    const thead = document.createElement("thead");
    thead.innerHTML = `
      <tr class="bg-primary text-white">
        ${headers.map(h => `<th>${h}</th>`).join("")}
      </tr>
    `;

    // Body
    const tbody = document.createElement("tbody");
    data.forEach(item => {
      const tr = document.createElement("tr");
      tr.innerHTML = fields.map(field => `
        <td>${item[field]}</td>
      `).join("");
      tbody.appendChild(tr);
    });

    table.appendChild(thead);
    table.appendChild(tbody);
    container.appendChild(table);
  }

  // Render no data message
  renderNoData() {
    const container = document.querySelector(".active-students-container");
    if (container) {
      container.innerHTML = "<h6>Tidak ada data untuk bulan ini</h6>";
    }
  }

  // Handle errors
  handleError(error) {
    console.error("Error in ActiveStudentData:", error);
    const container = document.querySelector(".active-students-container");
    if (container) {
      container.innerHTML = `
        <div class="text-danger">
          <h6>Gagal memuat data siswa</h6>
          <small>${error.message}</small>
        </div>
      `;
    }
  }

  // Cleanup function
  cleanup() {
    this.unsubscribeFunctions.forEach(unsubscribe => unsubscribe());
    this.unsubscribeFunctions = [];
  }

  // Initialize with real-time updates
  async init(selectedMonth) {
    try {
      // Cleanup existing listeners
      this.cleanup();
      
      // Set loading state
      this.setLoadingState();
      
      // Get teacher's classes
      await this.getTeacherClasses();
      
      // Setup real-time listener
      await this.setupActiveStudentsListener(selectedMonth);
    } catch (error) {
      this.handleError(error);
    }
  }
}

export default ActiveStudentData; 