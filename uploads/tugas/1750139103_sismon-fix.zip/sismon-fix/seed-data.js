// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, collection, addDoc, doc, setDoc, writeBatch, getDocs } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// Your Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCnYfcVqeNix7hyf1czx5PD6BNTR0xNdmg",
    authDomain: "tujuhebat-75d9d.firebaseapp.com",
    projectId: "tujuhebat-75d9d",
    storageBucket: "tujuhebat-75d9d.firebasestorage.app",
    messagingSenderId: "1042155779289",
    appId: "1:1042155779289:web:9ea609e5cb824d3ddf7ac8",
    measurementId: "G-BCMDF2YLBB"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Helper functions
function generateRandomString(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

function generateRandomDate(start, end) {
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function generateRandomActivityType() {
    const types = ['Membaca', 'Menulis', 'Berhitung', 'Menggambar', 'Olahraga', 'Bermain', 'Belajar'];
    return types[Math.floor(Math.random() * types.length)];
}

function generateRandomDuration() {
    return Math.floor(Math.random() * 120) + 1; // 1-120 minutes
}

// Generate dummy image data (base64 placeholder)
function generateDummyImage() {
    // This is a small transparent PNG in base64
    return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=';
}

// Generate seed data
async function generateSeedData() {
    try {
        // Create classes first
        const classes = [
            { className: '7A' },
            { className: '7B' },
            { className: '7C' },
            { className: '8A' },
            { className: '8B' },
            { className: '8C' },
            { className: '9A' },
            { className: '9B' },
            { className: '9C' }
        ];

        const classIds = [];
        const classBatch = writeBatch(db);

        for (const classData of classes) {
            const classRef = doc(collection(db, 'classes'));
            classBatch.set(classRef, classData);
            classIds.push(classRef.id);
        }
        await classBatch.commit();
        console.log('Classes created successfully');

        // Create students
        const students = [];
        const numStudents = 5; // Fixed at 5 students
        const batchSize = 500;
        let currentBatch = writeBatch(db);
        let opsCount = 0;

        for (let i = 0; i < numStudents; i++) {
            const studentId = generateRandomString(20);
            const studentData = {
                name: `Siswa ${i + 1}`,
                role: 'student',
                class: classIds[Math.floor(Math.random() * classIds.length)],
                email: `student${i + 1}@example.com`
            };

            const studentRef = doc(db, 'users', studentId);
            currentBatch.set(studentRef, studentData);
            opsCount++;
            students.push({ id: studentId, ...studentData });

            if (opsCount >= batchSize) {
                await currentBatch.commit();
                currentBatch = writeBatch(db);
                opsCount = 0;
                console.log(`Created ${i + 1} students`);
            }
        }

        if (opsCount > 0) {
            await currentBatch.commit();
        }
        console.log('Students created successfully');

        // Create activities for each student
        const activitiesPerStudent = 20; // Default to 20 activities per student
        let activityCount = 0;
        currentBatch = writeBatch(db);
        opsCount = 0;

        // More focused activity types
        const activityTypes = [
            { type: 'Membaca', weight: 0.3 },
            { type: 'Menulis', weight: 0.3 },
            { type: 'Berhitung', weight: 0.2 },
            { type: 'Menggambar', weight: 0.1 },
            { type: 'Olahraga', weight: 0.1 }
        ];

        function getWeightedRandomActivity() {
            const random = Math.random();
            let sum = 0;
            for (const activity of activityTypes) {
                sum += activity.weight;
                if (random <= sum) return activity.type;
            }
            return activityTypes[0].type;
        }

        for (const student of students) {
            for (let i = 0; i < activitiesPerStudent; i++) {
                const activityId = generateRandomString(20);
                const activityData = {
                    activityType: getWeightedRandomActivity(),
                    duration: generateRandomDuration(),
                    createdAt: generateRandomDate(new Date(2023, 0, 1), new Date()),
                    imageBase64: generateDummyImage(),
                    parentPhoto: generateDummyImage(),
                    parentSignature: generateDummyImage(),
                    validated: Math.random() > 0.5
                };

                const mainActivityRef = doc(db, 'activities', activityId);
                currentBatch.set(mainActivityRef, {
                    ...activityData,
                    userId: student.id
                });
                opsCount++;

                const studentActivityRef = doc(db, `users/${student.id}/activities`, activityId);
                currentBatch.set(studentActivityRef, activityData);
                opsCount++;

                activityCount++;

                if (opsCount >= batchSize) {
                    await currentBatch.commit();
                    currentBatch = writeBatch(db);
                    opsCount = 0;
                    console.log(`Created ${activityCount} activities`);
                }
            }
        }

        if (opsCount > 0) {
            await currentBatch.commit();
        }

        console.log('Seed data generation completed successfully');
        console.log(`Created ${classes.length} classes`);
        console.log(`Created ${students.length} students`);
        console.log(`Created ${activityCount} activities`);
    } catch (error) {
        console.error('Error generating seed data:', error);
        throw error;
    }
}


// Function to clear only seed-generated data
async function clearSeedData() {
    try {
        // Note: This will only clear data that matches seed data patterns
        const collections = ['users', 'classes', 'activities'];
        
        for (const collectionName of collections) {
            const snapshot = await getDocs(collection(db, collectionName));
            const batch = writeBatch(db);
            
            snapshot.docs.forEach(doc => {
                const data = doc.data();
                
                // Check if the document matches seed data patterns
                let shouldDelete = false;
                
                if (collectionName === 'users') {
                    // Check if it's a seed-generated student
                    if (data.role === 'student' && 
                        data.name && data.name.startsWith('Siswa ') && 
                        data.email && data.email.includes('@example.com')) {
                        shouldDelete = true;
                    }
                } 
                else if (collectionName === 'classes') {
                    // Check if it's a seed-generated class
                    if (data.className && 
                        ['7A', '7B', '7C', '8A', '8B', '8C', '9A', '9B', '9C'].includes(data.className)) {
                        shouldDelete = true;
                    }
                }
                else if (collectionName === 'activities') {
                    // Check if it's a seed-generated activity
                    if (data.activityType && 
                        ['Membaca', 'Menulis', 'Berhitung', 'Menggambar', 'Olahraga', 'Bermain', 'Belajar'].includes(data.activityType) &&
                        data.imageBase64 === generateDummyImage()) {
                        shouldDelete = true;
                    }
                }
                
                if (shouldDelete) {
                    batch.delete(doc.ref);
                }
            });
            
            await batch.commit();
            console.log(`Cleared seed data from ${collectionName} collection`);
        }

        // Clear seed-generated activities from user subcollections
        const usersSnapshot = await getDocs(collection(db, 'users'));
        for (const userDoc of usersSnapshot.docs) {
            const userData = userDoc.data();
            
            // Only check seed-generated students
            if (userData.role === 'student' && 
                userData.name && userData.name.startsWith('Siswa ') && 
                userData.email && userData.email.includes('@example.com')) {
                
                const activitiesSnapshot = await getDocs(collection(db, `users/${userDoc.id}/activities`));
                const batch = writeBatch(db);
                
                activitiesSnapshot.docs.forEach(doc => {
                    const activityData = doc.data();
                    // Check if it's a seed-generated activity
                    if (activityData.activityType && 
                        ['Membaca', 'Menulis', 'Berhitung', 'Menggambar', 'Olahraga', 'Bermain', 'Belajar'].includes(activityData.activityType) &&
                        activityData.imageBase64 === generateDummyImage()) {
                        batch.delete(doc.ref);
                    }
                });
                
                await batch.commit();
            }
        }

        console.log('Seed data cleared successfully');
    } catch (error) {
        console.error('Error clearing seed data:', error);
        throw error;
    }
}

// Export functions for use in HTML
window.seedData = {
    generate: generateSeedData,
    clear: clearSeedData
}; 